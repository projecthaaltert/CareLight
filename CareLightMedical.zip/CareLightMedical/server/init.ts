import { db } from './db';
import { users } from '@shared/schema';
import { hashPassword } from './auth';
import { log } from './vite';
import { eq } from 'drizzle-orm';

// Controleer of de admin gebruiker al bestaat en maak deze aan indien nodig
export async function initializeDatabase() {
  try {
    const adminUsers = await db.select().from(users).where(eq(users.username, 'emiovdp'));

    if (adminUsers.length === 0) {
      log('Geen admin account gevonden, een nieuw admin account wordt aangemaakt', 'init');
      const hashedPassword = await hashPassword('Kvdp2014');
      
      await db.insert(users).values({
        username: 'emiovdp',
        password: hashedPassword,
        fullName: 'Administrator',
        email: 'admin@carelight.nl',
        role: 'admin',
        specialty: null,
        registrationNumber: null,
      });
      
      log('Admin account succesvol aangemaakt', 'init');
    } else {
      log('Admin account bestaat al', 'init');
    }
  } catch (error) {
    log(`Fout bij initialiseren van de database: ${error}`, 'init');
  }
}
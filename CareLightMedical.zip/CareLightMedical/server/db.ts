import { drizzle } from "drizzle-orm/neon-http";
import { neon, neonConfig } from "@neondatabase/serverless";
import * as schema from "@shared/schema";

// Neon configuratie
neonConfig.fetchConnectionCache = true;

// Verbind met Neon PostgreSQL via de DATABASE_URL omgevingsvariabele
const sql = neon(process.env.DATABASE_URL!);
export const db = drizzle(sql, { schema });

// Export Database schema voor de drizzle CLI
export * from "@shared/schema";
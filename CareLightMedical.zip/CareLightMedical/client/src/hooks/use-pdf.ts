import { useCallback } from "react";
import { useToast } from "./use-toast";

interface UsePdfOptions {
  onError?: (error: Error) => void;
}

export function usePdf({ onError }: UsePdfOptions = {}) {
  const { toast } = useToast();
  
  const fetchAndDownloadPdf = useCallback(
    async (url: string, filename: string) => {
      try {
        const response = await fetch(url, {
          credentials: "include",
        });
        
        if (!response.ok) {
          throw new Error(`Failed to download PDF: ${response.status} ${response.statusText}`);
        }
        
        const blob = await response.blob();
        const downloadUrl = window.URL.createObjectURL(blob);
        const link = document.createElement("a");
        
        link.href = downloadUrl;
        link.setAttribute("download", filename);
        document.body.appendChild(link);
        link.click();
        
        // Clean up
        document.body.removeChild(link);
        window.URL.revokeObjectURL(downloadUrl);
        
        toast({
          title: "Download successful",
          description: `${filename} has been downloaded.`,
        });
      } catch (error) {
        console.error("PDF download error:", error);
        
        toast({
          title: "Download failed",
          description: error instanceof Error ? error.message : "Failed to download PDF",
          variant: "destructive",
        });
        
        if (onError && error instanceof Error) {
          onError(error);
        }
      }
    },
    [toast, onError]
  );
  
  return { fetchAndDownloadPdf };
}

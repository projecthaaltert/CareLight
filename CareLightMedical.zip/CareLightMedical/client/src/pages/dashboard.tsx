import { useQuery } from "@tanstack/react-query";
import Layout from "@/components/layout/layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Patient, Appointment, Prescription } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { CalendarClock, Users, FileText, AlertCircle } from "lucide-react";
import { format } from "date-fns";

export default function Dashboard() {
  const { user } = useAuth();

  const { data: patients, isLoading: isLoadingPatients } = useQuery<Patient[]>({
    queryKey: ["/api/patients"],
  });

  const { data: todayAppointments, isLoading: isLoadingAppointments } = useQuery<Appointment[]>({
    queryKey: ["/api/doctors", user?.id, "appointments"],
    enabled: !!user && user.role === "doctor",
  });

  const { data: recentPrescriptions, isLoading: isLoadingPrescriptions } = useQuery<Prescription[]>({
    queryKey: ["/api/prescriptions"],
    enabled: !!user && user.role === "doctor",
  });

  // Filter appointments for today
  const today = new Date().toISOString().split('T')[0];
  const appointmentsToday = todayAppointments?.filter(
    (appointment) => appointment.date.toString() === today
  ) || [];

  return (
    <Layout>
      <div className="p-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-semibold text-gray-800">Dashboard</h1>
            <div className="flex items-center text-sm text-gray-500">
              <CalendarClock className="h-4 w-4 mr-1" />
              <span>{format(new Date(), "EEEE, d MMMM yyyy")}</span>
            </div>
          </div>
          
          <div className="mt-4 md:mt-0">
            <div className="text-sm text-gray-500">
              Welcome back, <span className="font-semibold">{user?.fullName}</span>
            </div>
            <div className="text-xs text-gray-400">{user?.role} {user?.specialization ? `• ${user.specialization}` : ''}</div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="bg-blue-100 p-3 rounded-full mr-4">
                  <Users className="h-6 w-6 text-primary-500" />
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">Total Patients</div>
                  <div className="text-2xl font-bold">
                    {isLoadingPatients ? "..." : patients?.length || 0}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="bg-orange-100 p-3 rounded-full mr-4">
                  <CalendarClock className="h-6 w-6 text-orange-500" />
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">Today's Appointments</div>
                  <div className="text-2xl font-bold">
                    {isLoadingAppointments ? "..." : appointmentsToday.length}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="bg-purple-100 p-3 rounded-full mr-4">
                  <FileText className="h-6 w-6 text-purple-500" />
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">Active Prescriptions</div>
                  <div className="text-2xl font-bold">
                    {isLoadingPrescriptions ? "..." : 
                      recentPrescriptions?.filter(p => p.status === "active").length || 0}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="bg-red-100 p-3 rounded-full mr-4">
                  <AlertCircle className="h-6 w-6 text-red-500" />
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">Pending Reports</div>
                  <div className="text-2xl font-bold">0</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Upcoming Appointments */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Today's Appointments</CardTitle>
              <CardDescription>Your schedule for today</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingAppointments ? (
                <div className="text-center py-6 text-gray-500">Loading appointments...</div>
              ) : appointmentsToday.length === 0 ? (
                <div className="text-center py-6 text-gray-500">No appointments scheduled for today</div>
              ) : (
                <div className="space-y-4">
                  {appointmentsToday.map((appointment) => (
                    <div key={appointment.id} className="flex items-start p-3 border border-gray-200 rounded-lg">
                      <div className="text-center bg-gray-100 rounded-lg border border-gray-200 p-2 w-14 mr-4">
                        <div className="text-xs text-gray-600 uppercase font-medium">
                          {format(new Date(appointment.date), "MMM")}
                        </div>
                        <div className="text-xl font-bold text-gray-800">
                          {format(new Date(appointment.date), "dd")}
                        </div>
                        <div className="text-xs text-gray-600">
                          {format(new Date(appointment.date), "EEE")}
                        </div>
                      </div>
                      <div className="flex-1">
                        <h3 className="text-sm font-medium text-gray-800">{appointment.title}</h3>
                        <p className="text-xs text-gray-500 mt-1">{appointment.description}</p>
                        <div className="mt-2 flex items-center text-xs text-gray-500">
                          <CalendarClock className="h-3 w-3 text-gray-400 mr-1" />
                          <span>{appointment.startTime} - {appointment.endTime}</span>
                          <span className="mx-2">•</span>
                          <span>{appointment.location}</span>
                        </div>
                      </div>
                      <div>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          appointment.status === 'confirmed' 
                            ? 'bg-green-100 text-green-800' 
                            : appointment.status === 'scheduled' 
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}>
                          {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Prescriptions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Recent Prescriptions</CardTitle>
              <CardDescription>Latest prescriptions you've issued</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingPrescriptions ? (
                <div className="text-center py-6 text-gray-500">Loading prescriptions...</div>
              ) : !recentPrescriptions || recentPrescriptions.length === 0 ? (
                <div className="text-center py-6 text-gray-500">No prescriptions found</div>
              ) : (
                <div className="space-y-4">
                  {recentPrescriptions.slice(0, 4).map((prescription) => (
                    <div key={prescription.id} className="flex items-start p-3 border border-gray-200 rounded-lg">
                      <div className="h-8 w-8 flex-shrink-0 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                        <FileText className="h-4 w-4 text-primary-500" />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between">
                          <h3 className="text-sm font-medium text-gray-900">{prescription.medication}</h3>
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            prescription.status === 'active' 
                              ? 'bg-green-100 text-green-800' 
                              : prescription.status === 'completed' 
                              ? 'bg-gray-100 text-gray-800'
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {prescription.status.charAt(0).toUpperCase() + prescription.status.slice(1)}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">
                          {prescription.dosage} - {prescription.frequency}
                        </p>
                        <div className="mt-1 text-xs text-gray-500">
                          {format(new Date(prescription.startDate), "MMM d, yyyy")}
                          {prescription.endDate && ` - ${format(new Date(prescription.endDate), "MMM d, yyyy")}`}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}

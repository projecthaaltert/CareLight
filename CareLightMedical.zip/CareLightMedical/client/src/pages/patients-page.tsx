import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import PatientList from "@/components/patients/patient-list";
import { useMediaQuery } from "@/hooks/use-mobile";

const PatientsPage = () => {
  const isMobile = useMediaQuery("(max-width: 768px)");

  return (
    <div className="flex flex-col h-screen">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar isMobile={isMobile} />
        <main className="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6">
          <PatientList />
        </main>
      </div>
    </div>
  );
};

export default PatientsPage;

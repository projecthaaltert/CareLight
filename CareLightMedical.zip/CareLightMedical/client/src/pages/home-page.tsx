import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import DashboardPage from "@/components/dashboard/dashboard-page";
import { useMediaQuery } from "@/hooks/use-mobile";

const HomePage = () => {
  const { user } = useAuth();
  const isMobile = useMediaQuery("(max-width: 768px)");
  const [isSidebarOpen, setIsSidebarOpen] = useState(!isMobile);

  // Update sidebar state when screen size changes
  useEffect(() => {
    setIsSidebarOpen(!isMobile);
  }, [isMobile]);

  return (
    <div className="flex flex-col h-screen">
      <Header />
      
      <div className="flex flex-1 overflow-hidden">
        <Sidebar isMobile={isMobile} />
        
        <main className="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6">
          <DashboardPage />
        </main>
      </div>
    </div>
  );
};

export default HomePage;

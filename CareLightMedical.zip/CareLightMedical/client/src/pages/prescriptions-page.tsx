import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Prescription, Patient } from "@shared/schema";
import { Loader2, Plus, Search, FileText, Download, Printer } from "lucide-react";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import { useMediaQuery } from "@/hooks/use-mobile";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import PrescriptionForm from "@/components/prescriptions/prescription-form";
import PrescriptionPreview from "@/components/prescriptions/prescription-preview";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const PrescriptionsPage = () => {
  const isMobile = useMediaQuery("(max-width: 768px)");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPatient, setSelectedPatient] = useState<string>("");
  const [showNewPrescriptionModal, setShowNewPrescriptionModal] = useState(false);
  const [showPrescriptionPreviewModal, setShowPrescriptionPreviewModal] = useState(false);
  const [selectedPrescription, setSelectedPrescription] = useState<Prescription | null>(null);
  const [selectedPatientForPrescription, setSelectedPatientForPrescription] = useState<number | null>(null);

  const { data: prescriptions, isLoading: isLoadingPrescriptions } = useQuery<Prescription[]>({
    queryKey: ['/api/prescriptions'],
  });

  const { data: patients, isLoading: isLoadingPatients } = useQuery<Patient[]>({
    queryKey: ['/api/patients'],
  });

  const isLoading = isLoadingPrescriptions || isLoadingPatients;

  const handleViewPrescription = (prescription: Prescription) => {
    setSelectedPrescription(prescription);
    setShowPrescriptionPreviewModal(true);
  };

  const handleNewPrescription = (patientId: number) => {
    setSelectedPatientForPrescription(patientId);
    setShowNewPrescriptionModal(true);
  };

  const getPatient = (patientId: number) => {
    return patients?.find(p => p.id === patientId);
  };

  const filteredPrescriptions = prescriptions?.filter(prescription => {
    let matches = true;
    
    // Filter by search query
    if (searchQuery) {
      const patient = getPatient(prescription.patientId);
      const patientName = patient ? `${patient.firstName} ${patient.lastName}` : "";
      const searchLower = searchQuery.toLowerCase();
      
      matches = matches && (
        prescription.medicationName.toLowerCase().includes(searchLower) ||
        patientName.toLowerCase().includes(searchLower)
      );
    }
    
    // Filter by selected patient
    if (selectedPatient) {
      matches = matches && prescription.patientId === parseInt(selectedPatient);
    }
    
    return matches;
  }) || [];

  return (
    <div className="flex flex-col h-screen">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar isMobile={isMobile} />
        <main className="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-semibold text-neutral-800">Voorschriften</h1>
              <p className="text-neutral-600">Beheer en genereer voorschriften voor patiënten</p>
            </div>

            <div className="mt-4 md:mt-0 flex flex-col sm:flex-row gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" />
                <Input
                  placeholder="Zoek voorschriften..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              {patients && patients.length > 0 && (
                <Select
                  value={selectedPatient}
                  onValueChange={setSelectedPatient}
                >
                  <SelectTrigger className="w-full sm:w-[200px]">
                    <SelectValue placeholder="Alle patiënten" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Alle patiënten</SelectItem>
                    {patients.map((patient) => (
                      <SelectItem 
                        key={patient.id} 
                        value={patient.id.toString()}
                      >
                        {patient.firstName} {patient.lastName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          </div>

          {isLoading ? (
            <div className="h-64 flex items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <>
              {filteredPrescriptions.length === 0 ? (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-10">
                    <FileText className="h-10 w-10 text-neutral-300 mb-3" />
                    <p className="text-center text-neutral-600">
                      {searchQuery || selectedPatient ? "Geen voorschriften gevonden voor uw zoekopdracht." : "Geen voorschriften gevonden. Voeg een nieuw voorschrift toe via een patiëntdossier."}
                    </p>
                    {(searchQuery || selectedPatient) && (
                      <Button variant="outline" className="mt-4" onClick={() => {
                        setSearchQuery("");
                        setSelectedPatient("");
                      }}>
                        Wis zoekopdracht
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-6">
                  {patients?.map(patient => {
                    const patientPrescriptions = filteredPrescriptions.filter(p => p.patientId === patient.id);
                    if (patientPrescriptions.length === 0) return null;
                    
                    return (
                      <Card key={patient.id}>
                        <CardHeader className="flex flex-row items-center justify-between pb-2">
                          <div>
                            <CardTitle className="text-lg font-semibold">
                              {patient.firstName} {patient.lastName}
                            </CardTitle>
                            <p className="text-sm text-neutral-500">
                              {format(new Date(patient.birthDate), 'dd MMMM yyyy', { locale: nl })}
                            </p>
                          </div>
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="flex items-center"
                            onClick={() => handleNewPrescription(patient.id)}
                          >
                            <Plus className="h-4 w-4 mr-1" />
                            Nieuw voorschrift
                          </Button>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            {patientPrescriptions
                              .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                              .map((prescription) => (
                                <div 
                                  key={prescription.id}
                                  className="border border-neutral-200 rounded-md p-4 hover:bg-neutral-50 transition-colors"
                                >
                                  <div className="flex flex-col md:flex-row md:items-center justify-between">
                                    <div>
                                      <h4 className="font-medium text-neutral-800">
                                        {prescription.medicationName}
                                      </h4>
                                      <p className="text-sm text-neutral-600 mt-1">
                                        Voorgeschreven op: {format(new Date(prescription.date), 'dd-MM-yyyy')}
                                      </p>
                                    </div>
                                    <div className="flex items-center mt-3 md:mt-0">
                                      <Button 
                                        variant="outline" 
                                        size="sm"
                                        className="flex items-center mr-2"
                                        onClick={() => handleViewPrescription(prescription)}
                                      >
                                        <Printer className="h-4 w-4 mr-1" />
                                        Afdrukken
                                      </Button>
                                      {prescription.pdfUrl && (
                                        <Button 
                                          variant="outline" 
                                          size="sm"
                                          className="flex items-center"
                                          asChild
                                        >
                                          <a 
                                            href={prescription.pdfUrl} 
                                            target="_blank" 
                                            rel="noopener noreferrer"
                                          >
                                            <Download className="h-4 w-4 mr-1" />
                                            PDF
                                          </a>
                                        </Button>
                                      )}
                                    </div>
                                  </div>
                                  
                                  <div className="mt-3">
                                    <p className="text-sm text-neutral-700">
                                      <span className="font-medium">Dosering:</span> {prescription.dosage}
                                    </p>
                                    <p className="text-sm text-neutral-700">
                                      <span className="font-medium">Hoeveelheid:</span> {prescription.quantity} {prescription.quantityUnit}
                                    </p>
                                    <p className="text-sm text-neutral-700">
                                      <span className="font-medium">Gebruik:</span> {prescription.instructions}
                                    </p>
                                  </div>
                                </div>
                              ))}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {/* New Prescription Modal */}
          {selectedPatientForPrescription !== null && (
            <Dialog open={showNewPrescriptionModal} onOpenChange={setShowNewPrescriptionModal}>
              <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Nieuw voorschrift</DialogTitle>
                </DialogHeader>
                <PrescriptionForm 
                  patientId={selectedPatientForPrescription}
                  patient={getPatient(selectedPatientForPrescription)!}
                  onSuccess={(prescription) => {
                    setShowNewPrescriptionModal(false);
                    setSelectedPrescription(prescription);
                    setShowPrescriptionPreviewModal(true);
                  }}
                  onCancel={() => setShowNewPrescriptionModal(false)}
                />
              </DialogContent>
            </Dialog>
          )}
          
          {/* Prescription Preview Modal */}
          {selectedPrescription && getPatient(selectedPrescription.patientId) && (
            <Dialog open={showPrescriptionPreviewModal} onOpenChange={setShowPrescriptionPreviewModal}>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Voorschrift Voorbeeld</DialogTitle>
                </DialogHeader>
                <PrescriptionPreview 
                  prescription={selectedPrescription}
                  patient={getPatient(selectedPrescription.patientId)!}
                  onClose={() => setShowPrescriptionPreviewModal(false)}
                />
              </DialogContent>
            </Dialog>
          )}
        </main>
      </div>
    </div>
  );
};

export default PrescriptionsPage;

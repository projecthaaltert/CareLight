import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Layout from "@/components/layout/layout";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MedicalReport, Patient } from "@shared/schema";
import { usePdf } from "@/hooks/use-pdf";
import ReportModal from "@/components/reports/report-modal";
import { format } from "date-fns";
import {
  Plus,
  Search,
  Download,
  Edit,
  FileText,
  User,
  Calendar,
  Loader2,
  Bot,
  ClipboardList
} from "lucide-react";

export default function Reports() {
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPatientId, setSelectedPatientId] = useState<number | null>(null);
  const [showReportModal, setShowReportModal] = useState(false);
  const [aiFilterEnabled, setAiFilterEnabled] = useState<boolean | null>(null);
  const { fetchAndDownloadPdf } = usePdf();
  
  // Get all reports
  const { data: reports, isLoading: isLoadingReports } = useQuery<MedicalReport[]>({
    queryKey: ["/api/reports"],
  });
  
  // Get all patients for the dropdown
  const { data: patients, isLoading: isLoadingPatients } = useQuery<Patient[]>({
    queryKey: ["/api/patients"],
  });
  
  // Filter reports based on search, patient, and AI generated status
  const filteredReports = reports?.filter(report => {
    let matchesSearch = true;
    let matchesPatient = true;
    let matchesAiFilter = true;
    
    // Search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      matchesSearch = report.title.toLowerCase().includes(query) || 
                     report.content.toLowerCase().includes(query);
    }
    
    // Patient filter
    if (selectedPatientId !== null) {
      matchesPatient = report.patientId === selectedPatientId;
    }
    
    // AI filter
    if (aiFilterEnabled !== null) {
      matchesAiFilter = report.aiGenerated === aiFilterEnabled;
    }
    
    return matchesSearch && matchesPatient && matchesAiFilter;
  });
  
  const handleDownloadPdf = (reportId: number) => {
    fetchAndDownloadPdf(
      `/api/reports/${reportId}/pdf`,
      `medical_report_${reportId}.pdf`
    );
  };
  
  const openNewReportModal = (patientId?: number) => {
    if (patientId) {
      setSelectedPatientId(patientId);
    }
    setShowReportModal(true);
  };
  
  const findPatientName = (patientId: number) => {
    const patient = patients?.find(p => p.id === patientId);
    return patient ? `${patient.firstName} ${patient.lastName}` : `Patient #${patientId}`;
  };
  
  const isLoading = isLoadingReports || isLoadingPatients;
  
  return (
    <Layout>
      <div className="p-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
          <div>
            <h1 className="text-2xl font-semibold text-gray-800">Medical Reports</h1>
            <p className="text-sm text-gray-500">
              Create and manage patient medical reports
            </p>
          </div>
          
          <div className="mt-4 md:mt-0">
            <Button onClick={() => openNewReportModal()}>
              <Plus className="h-4 w-4 mr-2" />
              New Report
            </Button>
          </div>
        </div>
        
        <div className="bg-white rounded-lg border border-gray-200 mb-6">
          <div className="p-4 border-b border-gray-200">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  placeholder="Search reports..."
                  className="pl-9"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              
              <div className="flex gap-4">
                <div className="w-64">
                  <Select
                    value={selectedPatientId?.toString() || ""}
                    onValueChange={(value) => setSelectedPatientId(value ? parseInt(value) : null)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="All Patients" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All Patients</SelectItem>
                      {patients?.map((patient) => (
                        <SelectItem key={patient.id} value={patient.id.toString()}>
                          {patient.firstName} {patient.lastName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>
          
          <div className="p-4">
            <Tabs defaultValue="all">
              <TabsList>
                <TabsTrigger value="all" onClick={() => setAiFilterEnabled(null)}>
                  All Reports
                </TabsTrigger>
                <TabsTrigger value="manual" onClick={() => setAiFilterEnabled(false)}>
                  Manual Reports
                </TabsTrigger>
                <TabsTrigger value="ai" onClick={() => setAiFilterEnabled(true)}>
                  AI Generated
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          
          {isLoading ? (
            <div className="text-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary-500 mx-auto" />
              <p className="mt-2 text-gray-500">Loading reports...</p>
            </div>
          ) : !filteredReports || filteredReports.length === 0 ? (
            <div className="text-center py-12">
              <ClipboardList className="h-12 w-12 text-gray-300 mx-auto mb-3" />
              <h3 className="text-lg font-medium text-gray-900">No reports found</h3>
              <p className="text-gray-500 mt-1">
                {searchQuery || selectedPatientId !== null || aiFilterEnabled !== null
                  ? "No reports match your filter criteria." 
                  : "You haven't created any medical reports yet."}
              </p>
              <Button className="mt-4" onClick={() => openNewReportModal()}>
                <Plus className="h-4 w-4 mr-2" />
                Create Medical Report
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead>Patient</TableHead>
                    <TableHead>Report Title</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Creator</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredReports.map((report) => (
                    <TableRow key={report.id} className="hover:bg-gray-50">
                      <TableCell>
                        <div className="flex items-center">
                          <User className="h-8 w-8 text-gray-400 bg-gray-100 p-1.5 rounded-full mr-2" />
                          <div>
                            <p>{findPatientName(report.patientId)}</p>
                            <p className="text-xs text-gray-500">
                              ID: {report.patientId}
                            </p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <FileText className="h-8 w-8 flex-shrink-0 bg-purple-100 rounded-full p-2 text-purple-500 mr-2" />
                          <div>
                            <p className="font-medium">{report.title}</p>
                            <p className="text-xs text-gray-500">
                              {report.content.slice(0, 30)}...
                            </p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1 text-gray-400" />
                          <span>{format(new Date(report.date), "MMM d, yyyy")}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {report.aiGenerated ? (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                            <Bot className="h-3 w-3 mr-1" />
                            AI Generated
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                            Manual
                          </span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">Doctor #{report.doctorId}</div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0" 
                            onClick={() => handleDownloadPdf(report.id)}
                            title="Download PDF"
                          >
                            <Download className="h-4 w-4 text-primary-500" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0" 
                            title="Edit Report"
                          >
                            <Edit className="h-4 w-4 text-gray-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
      </div>
      
      {showReportModal && (
        <ReportModal 
          patientId={selectedPatientId || 0}
          isOpen={showReportModal}
          onClose={() => {
            setShowReportModal(false);
            if (!patients?.find(p => p.id === selectedPatientId)) {
              setSelectedPatientId(null);
            }
          }}
        />
      )}
    </Layout>
  );
}

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import ReportForm from "./report-form";
import { usePdf } from "@/hooks/use-pdf";
import { toast } from "@/hooks/use-toast";
import { useState } from "react";

interface ReportModalProps {
  patientId: number;
  isOpen: boolean;
  onClose: () => void;
}

export default function ReportModal({ patientId, isOpen, onClose }: ReportModalProps) {
  const [newReportId, setNewReportId] = useState<number | null>(null);
  const { fetchAndDownloadPdf } = usePdf();
  
  const handleSuccess = (data: any) => {
    setNewReportId(data?.id || null);
  };
  
  const handleGeneratePdf = () => {
    if (newReportId) {
      fetchAndDownloadPdf(
        `/api/reports/${newReportId}/pdf`, 
        `medical_report_${newReportId}.pdf`
      );
    } else {
      toast({
        title: "Error",
        description: "Cannot generate PDF as the report hasn't been saved yet.",
        variant: "destructive",
      });
    }
  };
  
  const handleCancel = () => {
    onClose();
    // Reset report ID after closing the modal
    setTimeout(() => setNewReportId(null), 300);
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>New Medical Report</DialogTitle>
          <DialogDescription>
            Create a comprehensive medical report for the patient
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          <ReportForm 
            patientId={patientId} 
            onSuccess={handleSuccess} 
            onCancel={handleCancel} 
          />
        </div>
        
        <DialogFooter>
          <div className="w-full flex justify-between items-center">
            <Button
              type="button"
              variant="outline"
              onClick={handleCancel}
            >
              Cancel
            </Button>
            
            <div>
              {newReportId && (
                <Button 
                  variant="default" 
                  className="bg-amber-500 hover:bg-amber-600 ml-2" 
                  onClick={handleGeneratePdf}
                >
                  Generate PDF
                </Button>
              )}
            </div>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

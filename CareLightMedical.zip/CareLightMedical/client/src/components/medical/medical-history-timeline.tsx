import { useQuery } from "@tanstack/react-query";
import { MedicalHistory } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { 
  ChevronRight, 
  Stethoscope, 
  Activity, 
  Flask, 
  Pill, 
  FileText,
  CheckCircle,
  User,
  Calendar
} from "lucide-react";

interface MedicalHistoryTimelineProps {
  patientId: number;
}

export default function MedicalHistoryTimeline({ patientId }: MedicalHistoryTimelineProps) {
  const { data: medicalHistories, isLoading } = useQuery<MedicalHistory[]>({
    queryKey: ['/api/patients', patientId, 'medical-history'],
    enabled: !!patientId,
  });
  
  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'check-up':
        return <Stethoscope className="text-green-500 h-4 w-4" />;
      case 'treatment':
        return <Pill className="text-yellow-500 h-4 w-4" />;
      case 'test':
        return <Flask className="text-purple-600 h-4 w-4" />;
      case 'surgery':
        return <Activity className="text-blue-500 h-4 w-4" />;
      default:
        return <FileText className="text-gray-500 h-4 w-4" />;
    }
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'ongoing':
        return 'bg-blue-100 text-blue-800';
      case 'scheduled':
        return 'bg-yellow-100 text-yellow-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  return (
    <Card className="mb-6">
      <CardHeader className="px-4 py-3 border-b border-gray-100 flex justify-between items-center">
        <CardTitle className="text-base font-medium text-gray-800">Recent Medical History</CardTitle>
        <Button variant="link" size="sm" className="text-primary-500 hover:text-primary-600 p-0">
          <span>View All</span>
          <ChevronRight className="h-4 w-4 ml-1" />
        </Button>
      </CardHeader>
      
      <CardContent className="p-4">
        {isLoading ? (
          <div className="space-y-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex space-x-3">
                <Skeleton className="h-8 w-8 rounded-full flex-shrink-0" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-1/3" />
                  <Skeleton className="h-3 w-full" />
                  <Skeleton className="h-3 w-full" />
                  <Skeleton className="h-3 w-2/3" />
                </div>
              </div>
            ))}
          </div>
        ) : !medicalHistories || medicalHistories.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <FileText className="h-12 w-12 mx-auto mb-3 text-gray-300" />
            <p>No medical history records found for this patient.</p>
          </div>
        ) : (
          <div className="flow-root">
            <ul className="-mb-8">
              {medicalHistories.map((entry, index) => (
                <li key={entry.id}>
                  <div className="relative pb-8">
                    {index < medicalHistories.length - 1 && (
                      <span className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-gray-200" aria-hidden="true"></span>
                    )}
                    <div className="relative flex space-x-3">
                      <div>
                        <span className={`h-8 w-8 rounded-full ${
                          entry.type === 'check-up' ? 'bg-green-100' : 
                          entry.type === 'treatment' ? 'bg-yellow-100' : 
                          entry.type === 'surgery' ? 'bg-blue-100' : 
                          entry.type === 'test' ? 'bg-purple-100' : 'bg-gray-100'
                        } flex items-center justify-center ring-8 ring-white`}>
                          {getTypeIcon(entry.type)}
                        </span>
                      </div>
                      <div className="min-w-0 flex-1 pt-1.5 flex justify-between space-x-4">
                        <div>
                          <p className="text-sm text-gray-800 font-medium">{entry.title}</p>
                          <p className="text-sm text-gray-500 mt-1">{entry.description}</p>
                          <div className="mt-2 flex flex-wrap gap-2">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(entry.status)}`}>
                              <CheckCircle className="h-3 w-3 mr-1" />
                              {entry.status.charAt(0).toUpperCase() + entry.status.slice(1)}
                            </span>
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                              <User className="h-3 w-3 mr-1" />
                              {entry.provider}
                            </span>
                          </div>
                        </div>
                        <div className="text-right text-sm whitespace-nowrap text-gray-500">
                          <time dateTime={entry.date.toString()}>
                            <Calendar className="inline h-3 w-3 mr-1" />
                            {format(new Date(entry.date), "MMM d, yyyy")}
                          </time>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

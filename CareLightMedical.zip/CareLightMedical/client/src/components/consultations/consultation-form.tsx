import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { InsertConsultation, Patient, insertConsultationSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Loader2, Bot } from "lucide-react";
import { format } from "date-fns";

interface ConsultationFormProps {
  patientId: number;
  onSuccess: () => void;
  onCancel: () => void;
}

const formSchema = insertConsultationSchema.pick({
  title: true,
  date: true,
  time: true,
  type: true,
  symptoms: true,
  diagnosis: true,
  treatment: true,
}).extend({
  date: z.string().min(1, "Datum is verplicht"),
  tags: z.string().optional(),
});

type ConsultationFormValues = z.infer<typeof formSchema>;

const ConsultationForm: React.FC<ConsultationFormProps> = ({ patientId, onSuccess, onCancel }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [isGeneratingWithAI, setIsGeneratingWithAI] = useState(false);

  const { data: patient } = useQuery<Patient>({
    queryKey: [`/api/patients/${patientId}`],
  });

  // Create default values
  const defaultValues: Partial<ConsultationFormValues> = {
    title: "",
    date: format(new Date(), 'yyyy-MM-dd'),
    time: format(new Date(), 'HH:mm'),
    type: "routine",
    symptoms: "",
    diagnosis: "",
    treatment: "",
    tags: "",
  };

  const form = useForm<ConsultationFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues,
  });

  const createConsultationMutation = useMutation({
    mutationFn: async (data: ConsultationFormValues) => {
      // Extract and process tags
      const tagsArray = data.tags 
        ? data.tags.split(',').map(tag => tag.trim()).filter(tag => tag !== '')
        : [];
      
      // Prepare data for API
      const consultationData: InsertConsultation = {
        patientId: patientId,
        doctorId: user!.id,
        title: data.title,
        date: new Date(data.date),
        time: data.time,
        type: data.type,
        symptoms: data.symptoms,
        diagnosis: data.diagnosis,
        treatment: data.treatment,
        tags: tagsArray,
        notes: ""
      };
      
      const res = await apiRequest(
        "POST", 
        "/api/consultations", 
        consultationData
      );
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/consultations"] });
      queryClient.invalidateQueries({ queryKey: [`/api/patients/${patientId}/consultations`] });
      toast({
        title: "Consultatie toegevoegd",
        description: "De consultatie is succesvol aangemaakt.",
      });
      onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "Fout",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const generateAIReportMutation = useMutation({
    mutationFn: async (consultationData: {
      patientId: number;
      consultationData: {
        title: string;
        date: string;
        time: string;
        type: string;
        symptoms: string;
        diagnosis: string;
        treatment: string;
      };
    }) => {
      const res = await apiRequest(
        "POST",
        "/api/ai/generate-report",
        consultationData
      );
      return res.json();
    },
    onSuccess: (data) => {
      // Fill in the diagnosis field with AI-generated content
      if (data.content) {
        const diagnosisSection = data.content.split('DIAGNOSE')[1]?.split('BEHANDELPLAN')[0] || '';
        if (diagnosisSection) {
          form.setValue('diagnosis', diagnosisSection.trim());
        } else {
          form.setValue('diagnosis', data.content.trim());
        }
      }
      setIsGeneratingWithAI(false);
      toast({
        title: "AI verslag gegenereerd",
        description: "Het AI verslag is succesvol gegenereerd en ingevuld.",
      });
    },
    onError: (error: Error) => {
      setIsGeneratingWithAI(false);
      toast({
        title: "Fout bij het genereren van AI verslag",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ConsultationFormValues) => {
    createConsultationMutation.mutate(data);
  };

  const handleGenerateWithAI = () => {
    const formData = form.getValues();
    if (!formData.symptoms) {
      toast({
        title: "Symptomen vereist",
        description: "Vul de symptomen in om een AI-verslag te genereren.",
        variant: "destructive",
      });
      return;
    }

    setIsGeneratingWithAI(true);
    generateAIReportMutation.mutate({
      patientId,
      consultationData: {
        title: formData.title,
        date: formData.date,
        time: formData.time,
        type: formData.type,
        symptoms: formData.symptoms,
        diagnosis: formData.diagnosis || "",
        treatment: formData.treatment || "",
      },
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="mb-6">
          <Card className="bg-neutral-100 p-4 rounded-md">
            <div className="flex items-center">
              <div className="h-12 w-12 bg-neutral-200 rounded-full flex items-center justify-center mr-4">
                <span className="material-icons">person</span>
              </div>
              <div>
                {patient && (
                  <>
                    <h3 className="font-medium text-neutral-800">
                      {patient.firstName} {patient.lastName}
                    </h3>
                    <p className="text-sm text-neutral-600">
                      {patient.birthDate && format(new Date(patient.birthDate), 'dd-MM-yyyy')} ({patient.gender})
                    </p>
                  </>
                )}
              </div>
            </div>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Titel consultatie</FormLabel>
                <FormControl>
                  <Input placeholder="Bijv. Controle diabetes" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="type"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Type consultatie</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecteer type" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="routine">Routinecontrole</SelectItem>
                    <SelectItem value="followup">Follow-up</SelectItem>
                    <SelectItem value="emergency">Spoed</SelectItem>
                    <SelectItem value="initial">Eerste consult</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="date"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Datum</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="time"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Tijd</FormLabel>
                <FormControl>
                  <Input type="time" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="symptoms"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Klachten/Symptomen</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Beschrijf de klachten of symptomen van de patiënt..."
                  className="min-h-24" 
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="diagnosis"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Diagnose</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Noteer de diagnose..."
                  className="min-h-24" 
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="treatment"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Behandelplan</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Beschrijf het behandelplan..."
                  className="min-h-24" 
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="tags"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Tags</FormLabel>
              <FormControl>
                <Input 
                  placeholder="Bijv. diabetes, hypertensie (gescheiden door komma's)"
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="border-t border-neutral-200 pt-6">
          <div className="flex justify-between">
            <Button
              type="button"
              variant="outline"
              className="flex items-center"
              onClick={handleGenerateWithAI}
              disabled={isGeneratingWithAI}
            >
              {isGeneratingWithAI ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Bot className="mr-2 h-4 w-4" />
              )}
              Genereer verslag met AI
            </Button>
            
            <div>
              <Button
                type="button"
                variant="outline"
                onClick={onCancel}
                className="mr-3"
              >
                Annuleren
              </Button>
              <Button 
                type="submit"
                disabled={createConsultationMutation.isPending}
              >
                {createConsultationMutation.isPending && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                Opslaan
              </Button>
            </div>
          </div>
        </div>
      </form>
    </Form>
  );
};

export default ConsultationForm;

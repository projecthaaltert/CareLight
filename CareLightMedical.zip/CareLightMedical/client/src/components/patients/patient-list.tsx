import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Patient } from "@shared/schema";
import { Loader2, Search, Plus, UserPlus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import PatientForm from "./patient-form";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { format } from "date-fns";

const PatientList = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [showNewPatientModal, setShowNewPatientModal] = useState(false);

  const { data: patients, isLoading } = useQuery<Patient[]>({
    queryKey: ['/api/patients'],
  });

  if (isLoading) {
    return (
      <div className="h-full flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const filteredPatients = patients?.filter(patient => {
    if (!searchQuery) return true;
    
    const fullName = `${patient.firstName} ${patient.lastName}`.toLowerCase();
    const query = searchQuery.toLowerCase();
    
    return (
      fullName.includes(query) ||
      patient.rijksregisternummer?.includes(query) ||
      patient.email?.toLowerCase().includes(query) ||
      patient.phoneNumber?.includes(query)
    );
  }) || [];

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-semibold text-neutral-800">Patiënten</h1>
          <p className="text-neutral-600">Beheer uw patiëntengegevens</p>
        </div>

        <div className="mt-4 md:mt-0 flex flex-col sm:flex-row gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" />
            <Input
              placeholder="Zoek op patiënt..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button onClick={() => setShowNewPatientModal(true)}>
            <UserPlus className="h-4 w-4 mr-2" />
            Nieuwe patiënt
          </Button>
        </div>
      </div>

      {filteredPatients.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-10">
            <UserPlus className="h-10 w-10 text-neutral-300 mb-3" />
            <p className="text-center text-neutral-600">
              {searchQuery ? "Geen patiënten gevonden voor uw zoekopdracht." : "Geen patiënten gevonden. Voeg een nieuwe patiënt toe."}
            </p>
            {searchQuery && (
              <Button variant="outline" className="mt-4" onClick={() => setSearchQuery("")}>
                Wis zoekopdracht
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPatients.map((patient) => (
            <Link href={`/patients/${patient.id}`} key={patient.id}>
              <a className="block">
                <Card className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <div className="h-12 w-12 rounded-full bg-neutral-200 flex items-center justify-center text-neutral-500 mr-4">
                        <span className="material-icons">person</span>
                      </div>
                      <div>
                        <h3 className="font-medium text-neutral-800">
                          {patient.firstName} {patient.lastName}
                        </h3>
                        <p className="text-sm text-neutral-500">
                          {patient.rijksregisternummer || "Geen RRN"}
                        </p>
                      </div>
                    </div>

                    <div className="mt-4 space-y-2">
                      <p className="text-sm">
                        <span className="text-neutral-500">Geboortedatum: </span>
                        <span className="text-neutral-700">
                          {format(new Date(patient.birthDate), 'dd-MM-yyyy')}
                        </span>
                      </p>
                      <p className="text-sm">
                        <span className="text-neutral-500">Geslacht: </span>
                        <span className="text-neutral-700">{patient.gender}</span>
                      </p>
                      {patient.phoneNumber && (
                        <p className="text-sm">
                          <span className="text-neutral-500">Tel.: </span>
                          <span className="text-neutral-700">{patient.phoneNumber}</span>
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </a>
            </Link>
          ))}
        </div>
      )}

      <Dialog open={showNewPatientModal} onOpenChange={setShowNewPatientModal}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Nieuwe patiënt</DialogTitle>
          </DialogHeader>
          <PatientForm 
            onSuccess={() => setShowNewPatientModal(false)}
            onCancel={() => setShowNewPatientModal(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PatientList;

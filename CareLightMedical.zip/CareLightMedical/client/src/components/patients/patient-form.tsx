import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Patient, insertPatientSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

interface PatientFormProps {
  patient?: Patient;
  onSuccess: () => void;
  onCancel: () => void;
}

const formSchema = insertPatientSchema.extend({
  birthDate: z.string().min(1, "Geboortedatum is verplicht"),
});

type PatientFormValues = z.infer<typeof formSchema>;

const PatientForm: React.FC<PatientFormProps> = ({ patient, onSuccess, onCancel }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isEditing = !!patient;

  // Create default values
  const defaultValues: Partial<PatientFormValues> = {
    rijksregisternummer: patient?.rijksregisternummer || "",
    firstName: patient?.firstName || "",
    lastName: patient?.lastName || "",
    birthDate: patient?.birthDate
      ? new Date(patient.birthDate).toISOString().split("T")[0]
      : "",
    gender: patient?.gender || "",
    address: patient?.address || "",
    city: patient?.city || "",
    postalCode: patient?.postalCode || "",
    phoneNumber: patient?.phoneNumber || "",
    email: patient?.email || "",
    bloodType: patient?.bloodType || "",
    primaryDoctor: patient?.primaryDoctor || "",
  };

  const form = useForm<PatientFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues,
  });

  const createPatientMutation = useMutation({
    mutationFn: async (data: PatientFormValues) => {
      // Convert string date to Date object for API
      const formattedData = {
        ...data,
        birthDate: new Date(data.birthDate),
      };
      
      const res = await apiRequest(
        isEditing ? "PUT" : "POST",
        isEditing ? `/api/patients/${patient.id}` : "/api/patients",
        formattedData
      );
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/patients"] });
      if (isEditing) {
        queryClient.invalidateQueries({ queryKey: [`/api/patients/${patient.id}`] });
      }
      toast({
        title: isEditing ? "Patiënt bijgewerkt" : "Patiënt toegevoegd",
        description: isEditing
          ? "De patiëntgegevens zijn succesvol bijgewerkt."
          : "Nieuwe patiënt is succesvol toegevoegd.",
      });
      onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "Fout",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: PatientFormValues) => {
    createPatientMutation.mutate(data);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="mb-6">
          <Card className="bg-neutral-100 p-4 rounded-md">
            <div className="flex items-center">
              <div className="h-12 w-12 bg-neutral-200 rounded-full flex items-center justify-center mr-4">
                <span className="material-icons">person</span>
              </div>
              <div>
                <h3 className="font-medium text-neutral-800">
                  {isEditing ? "Bewerk patiëntgegevens" : "Nieuwe patiënt toevoegen"}
                </h3>
                {isEditing && (
                  <p className="text-sm text-neutral-600">
                    {patient.firstName} {patient.lastName}
                  </p>
                )}
              </div>
            </div>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="rijksregisternummer"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Rijksregisternummer</FormLabel>
                <FormControl>
                  <Input placeholder="00.00.00-000.00" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="birthDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Geboortedatum</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="firstName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Voornaam</FormLabel>
                <FormControl>
                  <Input placeholder="Voornaam" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="lastName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Achternaam</FormLabel>
                <FormControl>
                  <Input placeholder="Achternaam" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="gender"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Geslacht</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecteer geslacht" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="Man">Man</SelectItem>
                    <SelectItem value="Vrouw">Vrouw</SelectItem>
                    <SelectItem value="Anders">Anders</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="bloodType"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Bloedgroep</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecteer bloedgroep" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="A+">A+</SelectItem>
                    <SelectItem value="A-">A-</SelectItem>
                    <SelectItem value="B+">B+</SelectItem>
                    <SelectItem value="B-">B-</SelectItem>
                    <SelectItem value="AB+">AB+</SelectItem>
                    <SelectItem value="AB-">AB-</SelectItem>
                    <SelectItem value="O+">O+</SelectItem>
                    <SelectItem value="O-">O-</SelectItem>
                    <SelectItem value="Onbekend">Onbekend</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 gap-6">
          <FormField
            control={form.control}
            name="address"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Adres</FormLabel>
                <FormControl>
                  <Input placeholder="Straat en huisnummer" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="postalCode"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Postcode</FormLabel>
                <FormControl>
                  <Input placeholder="1234" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="city"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Plaats</FormLabel>
                <FormControl>
                  <Input placeholder="Plaats" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="phoneNumber"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Telefoonnummer</FormLabel>
                <FormControl>
                  <Input placeholder="+32 123 456 789" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>E-mail</FormLabel>
                <FormControl>
                  <Input placeholder="email@voorbeeld.com" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="primaryDoctor"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Huisarts</FormLabel>
              <FormControl>
                <Input placeholder="Dr. Naam" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="border-t border-neutral-200 pt-6">
          <div className="flex justify-end">
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              className="mr-3"
            >
              Annuleren
            </Button>
            <Button 
              type="submit"
              disabled={createPatientMutation.isPending}
            >
              {createPatientMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              {isEditing ? "Bijwerken" : "Toevoegen"}
            </Button>
          </div>
        </div>
      </form>
    </Form>
  );
};

export default PatientForm;

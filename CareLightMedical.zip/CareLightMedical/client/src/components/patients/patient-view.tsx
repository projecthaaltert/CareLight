import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Patient, Consultation, Prescription, Report } from "@shared/schema";
import { Loader2, Plus, FileText, Printer, Download, Clock, Tag } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import PatientCard from "./patient-card";
import PatientForm from "./patient-form";
import ConsultationForm from "../consultations/consultation-form";
import PrescriptionForm from "../prescriptions/prescription-form";
import PrescriptionPreview from "../prescriptions/prescription-preview";
import { useToast } from "@/hooks/use-toast";

interface PatientViewProps {
  patientId: number;
}

const PatientView: React.FC<PatientViewProps> = ({ patientId }) => {
  const [showEditPatientModal, setShowEditPatientModal] = useState(false);
  const [showNewConsultationModal, setShowNewConsultationModal] = useState(false);
  const [showNewPrescriptionModal, setShowNewPrescriptionModal] = useState(false);
  const [showPrescriptionPreviewModal, setShowPrescriptionPreviewModal] = useState(false);
  const [selectedPrescription, setSelectedPrescription] = useState<Prescription | null>(null);
  const [activeTab, setActiveTab] = useState("overview");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: patient, isLoading: patientLoading } = useQuery<Patient>({
    queryKey: [`/api/patients/${patientId}`],
  });

  const { data: consultations, isLoading: consultationsLoading } = useQuery<Consultation[]>({
    queryKey: [`/api/patients/${patientId}/consultations`],
  });

  const { data: prescriptions, isLoading: prescriptionsLoading } = useQuery<Prescription[]>({
    queryKey: [`/api/patients/${patientId}/prescriptions`],
  });

  const { data: reports, isLoading: reportsLoading } = useQuery<Report[]>({
    queryKey: [`/api/patients/${patientId}/reports`],
  });

  // Get active medications (from prescriptions)
  const activeMedications = prescriptions
    ? [...prescriptions]
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .filter((p, index, self) => 
          self.findIndex(t => t.medicationName === p.medicationName) === index
        )
        .slice(0, 5)
    : [];

  const handleViewPrescription = (prescription: Prescription) => {
    setSelectedPrescription(prescription);
    setShowPrescriptionPreviewModal(true);
  };

  const isLoading = patientLoading || consultationsLoading || prescriptionsLoading || reportsLoading;

  if (isLoading) {
    return (
      <div className="h-full flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!patient) {
    return (
      <div className="h-full flex items-center justify-center">
        <Card>
          <CardContent className="p-6">
            <p className="text-neutral-600">Patiënt niet gevonden</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="pb-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-semibold text-neutral-800">Patiëntdossier</h1>
          <p className="text-neutral-600">
            {patient.firstName} {patient.lastName}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Patient Info and Medications */}
        <div className="lg:col-span-1">
          <PatientCard 
            patient={patient} 
            onEdit={() => setShowEditPatientModal(true)} 
          />
          
          <Card className="bg-white mt-6">
            <div className="p-6 border-b border-neutral-200">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-neutral-800">Actieve medicatie</h2>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => setShowNewPrescriptionModal(true)}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <CardContent className="p-4">
              {activeMedications.length === 0 ? (
                <div className="text-neutral-500 text-center py-4">
                  Geen actieve medicatie
                </div>
              ) : (
                activeMedications.map((prescription) => (
                  <div 
                    key={prescription.id} 
                    className="p-2 border-b border-neutral-100 last:border-b-0"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-neutral-800">
                          {prescription.medicationName}
                        </p>
                        <p className="text-sm text-neutral-600">
                          {prescription.dosage}, {prescription.instructions}
                        </p>
                        <p className="text-xs text-neutral-500">
                          Sinds: {format(new Date(prescription.date), 'dd-MM-yyyy')}
                        </p>
                      </div>
                      <div className="flex items-center">
                        <Badge variant="success">Actief</Badge>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </div>
        
        {/* Medical History and Tabs */}
        <div className="lg:col-span-2">
          <Card className="bg-white">
            <Tabs defaultValue={activeTab} onValueChange={setActiveTab}>
              <div className="border-b border-neutral-200">
                <TabsList className="bg-transparent mx-6">
                  <TabsTrigger value="overview">Overzicht</TabsTrigger>
                  <TabsTrigger value="medical-history">Medische geschiedenis</TabsTrigger>
                  <TabsTrigger value="prescriptions">Voorschriften</TabsTrigger>
                  <TabsTrigger value="reports">Verslagen</TabsTrigger>
                </TabsList>
              </div>
              
              <TabsContent value="overview" className="p-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-neutral-800">Recente consultaties</h3>
                  <div className="flex items-center mt-3 md:mt-0">
                    <Button 
                      onClick={() => setShowNewConsultationModal(true)}
                      className="mr-2"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Nieuwe consultatie
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-4">
                  {consultations && consultations.length > 0 ? (
                    consultations
                      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                      .slice(0, 5)
                      .map((consultation) => (
                        <div 
                          key={consultation.id} 
                          className="border border-neutral-200 rounded-md p-4 hover:bg-neutral-50 transition-colors"
                        >
                          <div className="flex flex-col md:flex-row md:items-center justify-between">
                            <div>
                              <div className="flex items-center">
                                <h4 className="font-medium text-neutral-800">{consultation.title}</h4>
                                <Badge variant="outline" className="ml-2">
                                  Consultatie
                                </Badge>
                              </div>
                              <p className="text-sm text-neutral-600 mt-1">
                                {format(new Date(consultation.date), 'dd-MM-yyyy')}, {consultation.time}
                              </p>
                            </div>
                            <div className="flex items-center mt-3 md:mt-0">
                              <Button variant="ghost" size="icon">
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon">
                                <Printer className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                          
                          {consultation.diagnosis && (
                            <div className="mt-3">
                              <p className="text-neutral-700">{consultation.diagnosis}</p>
                            </div>
                          )}
                          
                          {consultation.tags && consultation.tags.length > 0 && (
                            <div className="mt-4 flex flex-wrap gap-2">
                              {consultation.tags.map((tag, index) => (
                                <Badge key={index} variant="secondary">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                      ))
                  ) : (
                    <Card>
                      <CardContent className="p-6 text-center text-neutral-500">
                        Geen consultaties gevonden
                      </CardContent>
                    </Card>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="medical-history">
                <div className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Medische geschiedenis</h3>
                  {consultations && consultations.length > 0 ? (
                    <div className="space-y-4">
                      {consultations
                        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                        .map((consultation) => (
                          <div 
                            key={consultation.id}
                            className="border border-neutral-200 rounded-md p-4"
                          >
                            <div className="flex items-center justify-between">
                              <h4 className="font-medium">{consultation.title}</h4>
                              <p className="text-sm text-neutral-500">
                                {format(new Date(consultation.date), 'dd MMM yyyy', { locale: nl })}
                              </p>
                            </div>
                            
                            {consultation.symptoms && (
                              <div className="mt-2">
                                <p className="text-sm font-medium">Symptomen:</p>
                                <p className="text-sm text-neutral-700">{consultation.symptoms}</p>
                              </div>
                            )}
                            
                            {consultation.diagnosis && (
                              <div className="mt-2">
                                <p className="text-sm font-medium">Diagnose:</p>
                                <p className="text-sm text-neutral-700">{consultation.diagnosis}</p>
                              </div>
                            )}
                            
                            {consultation.treatment && (
                              <div className="mt-2">
                                <p className="text-sm font-medium">Behandeling:</p>
                                <p className="text-sm text-neutral-700">{consultation.treatment}</p>
                              </div>
                            )}
                            
                            {consultation.tags && consultation.tags.length > 0 && (
                              <div className="mt-3 flex flex-wrap gap-2">
                                {consultation.tags.map((tag, index) => (
                                  <Badge key={index} variant="secondary">
                                    {tag}
                                  </Badge>
                                ))}
                              </div>
                            )}
                          </div>
                        ))}
                    </div>
                  ) : (
                    <Card>
                      <CardContent className="p-6 text-center text-neutral-500">
                        Geen medische geschiedenis gevonden
                      </CardContent>
                    </Card>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="prescriptions">
                <div className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
                    <h3 className="text-lg font-semibold text-neutral-800">Voorschriften</h3>
                    <Button onClick={() => setShowNewPrescriptionModal(true)}>
                      <Plus className="h-4 w-4 mr-2" />
                      Nieuw voorschrift
                    </Button>
                  </div>
                  
                  {prescriptions && prescriptions.length > 0 ? (
                    <div className="space-y-4">
                      {prescriptions
                        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                        .map((prescription) => (
                          <div 
                            key={prescription.id}
                            className="border border-neutral-200 rounded-md p-4 hover:bg-neutral-50 transition-colors"
                          >
                            <div className="flex flex-col md:flex-row md:items-center justify-between">
                              <div>
                                <h4 className="font-medium text-neutral-800">
                                  {prescription.medicationName}
                                </h4>
                                <p className="text-sm text-neutral-600 mt-1">
                                  Voorgeschreven op: {format(new Date(prescription.date), 'dd-MM-yyyy')}
                                </p>
                              </div>
                              <div className="flex items-center mt-3 md:mt-0">
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  className="flex items-center mr-2"
                                  onClick={() => handleViewPrescription(prescription)}
                                >
                                  <Printer className="h-4 w-4 mr-1" />
                                  Afdrukken
                                </Button>
                                {prescription.pdfUrl && (
                                  <Button 
                                    variant="outline" 
                                    size="sm"
                                    className="flex items-center"
                                    asChild
                                  >
                                    <a 
                                      href={prescription.pdfUrl} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                    >
                                      <Download className="h-4 w-4 mr-1" />
                                      PDF
                                    </a>
                                  </Button>
                                )}
                              </div>
                            </div>
                            
                            <div className="mt-3">
                              <p className="text-sm text-neutral-700">
                                <span className="font-medium">Dosering:</span> {prescription.dosage}
                              </p>
                              <p className="text-sm text-neutral-700">
                                <span className="font-medium">Hoeveelheid:</span> {prescription.quantity} {prescription.quantityUnit}
                              </p>
                              <p className="text-sm text-neutral-700">
                                <span className="font-medium">Gebruik:</span> {prescription.instructions}
                              </p>
                              {prescription.duration && (
                                <p className="text-sm text-neutral-700">
                                  <span className="font-medium">Duur:</span> {prescription.duration} {prescription.durationUnit}
                                </p>
                              )}
                            </div>
                          </div>
                        ))}
                    </div>
                  ) : (
                    <Card>
                      <CardContent className="p-6 text-center text-neutral-500">
                        Geen voorschriften gevonden
                      </CardContent>
                    </Card>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="reports">
                <div className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Medische verslagen</h3>
                  {reports && reports.length > 0 ? (
                    <div className="space-y-4">
                      {reports
                        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                        .map((report) => (
                          <div 
                            key={report.id}
                            className="border border-neutral-200 rounded-md p-4"
                          >
                            <div className="flex items-center justify-between mb-3">
                              <h4 className="font-medium">{report.title}</h4>
                              <div className="flex items-center">
                                <Badge 
                                  variant={report.aiGenerated ? "secondary" : "outline"}
                                  className="mr-2"
                                >
                                  {report.aiGenerated ? "AI gegenereerd" : "Handmatig"}
                                </Badge>
                                <p className="text-sm text-neutral-500">
                                  {format(new Date(report.date), 'dd MMM yyyy', { locale: nl })}
                                </p>
                              </div>
                            </div>
                            
                            <div className="prose prose-sm max-w-none">
                              <p>{report.content}</p>
                            </div>
                            
                            <div className="mt-4 flex justify-end">
                              {report.pdfUrl && (
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  className="flex items-center"
                                  asChild
                                >
                                  <a 
                                    href={report.pdfUrl} 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                  >
                                    <Download className="h-4 w-4 mr-1" />
                                    PDF
                                  </a>
                                </Button>
                              )}
                            </div>
                          </div>
                        ))}
                    </div>
                  ) : (
                    <Card>
                      <CardContent className="p-6 text-center text-neutral-500">
                        Geen verslagen gevonden
                      </CardContent>
                    </Card>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </Card>
        </div>
      </div>

      {/* Edit Patient Modal */}
      <Dialog open={showEditPatientModal} onOpenChange={setShowEditPatientModal}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Bewerk patiënt</DialogTitle>
          </DialogHeader>
          <PatientForm 
            patient={patient}
            onSuccess={() => setShowEditPatientModal(false)}
            onCancel={() => setShowEditPatientModal(false)}
          />
        </DialogContent>
      </Dialog>

      {/* New Consultation Modal */}
      <Dialog open={showNewConsultationModal} onOpenChange={setShowNewConsultationModal}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Nieuwe consultatie</DialogTitle>
          </DialogHeader>
          <ConsultationForm 
            patientId={patientId}
            onSuccess={() => {
              setShowNewConsultationModal(false);
              toast({
                title: "Consultatie toegevoegd",
                description: "De consultatie is succesvol toegevoegd.",
              });
            }}
            onCancel={() => setShowNewConsultationModal(false)}
          />
        </DialogContent>
      </Dialog>

      {/* New Prescription Modal */}
      <Dialog open={showNewPrescriptionModal} onOpenChange={setShowNewPrescriptionModal}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Nieuw voorschrift</DialogTitle>
          </DialogHeader>
          <PrescriptionForm 
            patientId={patientId}
            patient={patient}
            onSuccess={(prescription) => {
              setShowNewPrescriptionModal(false);
              setSelectedPrescription(prescription);
              setShowPrescriptionPreviewModal(true);
            }}
            onCancel={() => setShowNewPrescriptionModal(false)}
          />
        </DialogContent>
      </Dialog>
      
      {/* Prescription Preview Modal */}
      <Dialog open={showPrescriptionPreviewModal} onOpenChange={setShowPrescriptionPreviewModal}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Voorschrift Voorbeeld</DialogTitle>
          </DialogHeader>
          {selectedPrescription && (
            <PrescriptionPreview 
              prescription={selectedPrescription}
              patient={patient}
              onClose={() => setShowPrescriptionPreviewModal(false)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PatientView;

import { Patient, Insurance } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { differenceInYears, format } from "date-fns";
import { 
  Phone, 
  Mail, 
  Home, 
  Heart, 
  Activity, 
  AlertTriangle,
  CreditCard,
  Hash,
  Calendar,
  Clock,
  Download,
  Edit,
  History 
} from "lucide-react";

interface PatientInfoPanelProps {
  patient: Patient;
}

export default function PatientInfoPanel({ patient }: PatientInfoPanelProps) {
  const [, navigate] = useLocation();
  
  const { data: insurance } = useQuery<Insurance>({
    queryKey: ['/api/patients', patient.id, 'insurance'],
    enabled: !!patient.id,
  });
  
  const calculateAge = (dob: Date) => {
    return differenceInYears(new Date(), new Date(dob));
  };
  
  return (
    <Card className="mb-6 bg-white">
      <CardContent className="p-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
          <div className="flex items-center">
            <img 
              src={`https://ui-avatars.com/api/?name=${patient.firstName}+${patient.lastName}&background=1A6AA5&color=fff&size=128`}
              alt={`${patient.firstName} ${patient.lastName}`}
              className="w-16 h-16 rounded-full mr-4 border-2 border-primary-100"
            />
            <div>
              <h2 className="text-xl font-semibold text-gray-800">
                {patient.firstName} {patient.lastName}
              </h2>
              <div className="flex flex-col sm:flex-row sm:items-center text-sm text-gray-500 mt-1">
                <div className="flex items-center mr-4">
                  <Calendar className="h-4 w-4 mr-1" />
                  <span>{format(new Date(patient.dateOfBirth), "dd-MM-yyyy")}</span>
                  <span className="ml-1">({calculateAge(patient.dateOfBirth)} years)</span>
                </div>
                <div className="flex items-center mr-4 mt-1 sm:mt-0">
                  <Hash className="h-4 w-4 mr-1" />
                  <span>{patient.nationalId}</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-4 md:mt-0 flex">
            <Button 
              variant="outline" 
              size="sm" 
              className="mr-2"
              onClick={() => navigate(`/patients/${patient.id}/history`)}
            >
              <History className="h-4 w-4 mr-1" />
              History
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="mr-2"
            >
              <Download className="h-4 w-4 mr-1" />
              Export
            </Button>
            <Button 
              variant="default" 
              size="sm"
              onClick={() => navigate(`/patients/${patient.id}/edit`)}
            >
              <Edit className="h-4 w-4 mr-1" />
              Edit
            </Button>
          </div>
        </div>
        
        {/* Patient Details */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4 border-t border-gray-100 pt-4">
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-2">Contact Information</h3>
            <div className="space-y-2">
              <div className="flex items-start">
                <Phone className="text-gray-400 h-4 w-4 mr-2 mt-0.5" />
                <div>
                  <div className="text-sm font-medium">{patient.phone}</div>
                  <div className="text-xs text-gray-500">Mobile</div>
                </div>
              </div>
              <div className="flex items-start">
                <Mail className="text-gray-400 h-4 w-4 mr-2 mt-0.5" />
                <div>
                  <div className="text-sm font-medium">{patient.email || "No email provided"}</div>
                  <div className="text-xs text-gray-500">Email</div>
                </div>
              </div>
              <div className="flex items-start">
                <Home className="text-gray-400 h-4 w-4 mr-2 mt-0.5" />
                <div>
                  <div className="text-sm font-medium">{patient.address}</div>
                  <div className="text-xs text-gray-500">Home address</div>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-2">Medical Information</h3>
            <div className="space-y-2">
              <div className="flex items-start">
                <Heart className="text-gray-400 h-4 w-4 mr-2 mt-0.5" />
                <div>
                  <div className="text-sm font-medium">{patient.bloodType || "Not recorded"}</div>
                  <div className="text-xs text-gray-500">Blood Group</div>
                </div>
              </div>
              <div className="flex items-start">
                <Activity className="text-gray-400 h-4 w-4 mr-2 mt-0.5" />
                <div>
                  <div className="text-sm font-medium">
                    {patient.weight ? `${patient.weight}kg` : "?"}
                    {patient.height ? `, ${patient.height}cm` : ""}
                  </div>
                  <div className="text-xs text-gray-500">Weight, Height</div>
                </div>
              </div>
              <div className="flex items-start">
                <AlertTriangle className="text-gray-400 h-4 w-4 mr-2 mt-0.5" />
                <div>
                  <div className={`text-sm font-medium ${patient.allergies && patient.allergies.length > 0 ? "text-red-500" : ""}`}>
                    {patient.allergies && patient.allergies.length > 0 
                      ? patient.allergies.join(", ") 
                      : "No known allergies"}
                  </div>
                  <div className="text-xs text-gray-500">Allergies</div>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-2">Insurance Details</h3>
            <div className="space-y-2">
              {insurance ? (
                <>
                  <div className="flex items-start">
                    <CreditCard className="text-gray-400 h-4 w-4 mr-2 mt-0.5" />
                    <div>
                      <div className="text-sm font-medium">{insurance.provider}</div>
                      <div className="text-xs text-gray-500">Provider</div>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <Hash className="text-gray-400 h-4 w-4 mr-2 mt-0.5" />
                    <div>
                      <div className="text-sm font-medium">{insurance.policyNumber}</div>
                      <div className="text-xs text-gray-500">Policy Number</div>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <Clock className="text-gray-400 h-4 w-4 mr-2 mt-0.5" />
                    <div>
                      <div className="text-sm font-medium">
                        Valid until {format(new Date(insurance.validUntil), "dd-MM-yyyy")}
                      </div>
                      <div className="text-xs text-gray-500">Coverage Period</div>
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-sm text-gray-500">No insurance information available</div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

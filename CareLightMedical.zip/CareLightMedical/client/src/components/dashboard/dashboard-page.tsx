import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Users, Calendar, FileText, FileCheck, Activity } from "lucide-react";
import { Patient, Consultation, Prescription } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { format } from "date-fns";
import { nl } from "date-fns/locale";

const DashboardPage = () => {
  const { user } = useAuth();

  const { data: patients, isLoading: isLoadingPatients } = useQuery<Patient[]>({
    queryKey: ['/api/patients'],
  });

  const { data: consultations, isLoading: isLoadingConsultations } = useQuery<Consultation[]>({
    queryKey: ['/api/consultations'],
  });

  const { data: prescriptions, isLoading: isLoadingPrescriptions } = useQuery<Prescription[]>({
    queryKey: ['/api/prescriptions'],
  });

  if (isLoadingPatients || isLoadingConsultations || isLoadingPrescriptions) {
    return (
      <div className="h-full flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Get recent patient count - added in last 30 days
  const getRecentPatients = () => {
    if (!patients) return 0;
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    return patients.filter(
      (p) => new Date(p.createdAt) > thirtyDaysAgo
    ).length;
  };

  // Get consultations for today
  const getTodayConsultations = () => {
    if (!consultations) return [];
    const today = new Date().toISOString().split('T')[0];
    return consultations.filter(c => c.date.toString() === today);
  };

  // Get recent consultations - most recent 5
  const getRecentConsultations = () => {
    if (!consultations) return [];
    return [...consultations]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5);
  };

  // Get recent prescriptions - most recent 5
  const getRecentPrescriptions = () => {
    if (!prescriptions) return [];
    return [...prescriptions]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5);
  };

  // Find patient name by ID
  const getPatientName = (patientId: number) => {
    const patient = patients?.find(p => p.id === patientId);
    return patient ? `${patient.firstName} ${patient.lastName}` : 'Onbekende patiënt';
  };

  const todayConsultations = getTodayConsultations();
  const recentConsultations = getRecentConsultations();
  const recentPrescriptions = getRecentPrescriptions();

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-neutral-800">
        Welkom, {user?.fullName || 'Gebruiker'}
      </h1>

      {/* Dashboard cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Patiënten</CardTitle>
            <Users className="h-4 w-4 text-neutral-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{patients?.length || 0}</div>
            <p className="text-xs text-neutral-500 mt-1">
              {getRecentPatients()} nieuwe in 30 dagen
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Afspraken Vandaag</CardTitle>
            <Calendar className="h-4 w-4 text-neutral-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{todayConsultations.length}</div>
            <p className="text-xs text-neutral-500 mt-1">
              {todayConsultations.length > 0 ? 'Volgende om ' + todayConsultations[0].time : 'Geen afspraken'}
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Consultaties</CardTitle>
            <FileText className="h-4 w-4 text-neutral-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{consultations?.length || 0}</div>
            <p className="text-xs text-neutral-500 mt-1">
              {recentConsultations.length} in de afgelopen week
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Voorschriften</CardTitle>
            <FileCheck className="h-4 w-4 text-neutral-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{prescriptions?.length || 0}</div>
            <p className="text-xs text-neutral-500 mt-1">
              {recentPrescriptions.length} recente voorschriften
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Recent activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-medium flex items-center">
              <Activity className="mr-2 h-5 w-5" />
              Recente Consultaties
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentConsultations.length > 0 ? (
              <div className="space-y-4">
                {recentConsultations.map((consultation) => (
                  <div 
                    key={consultation.id} 
                    className="border-b border-neutral-100 last:border-0 pb-3 last:pb-0"
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between">
                      <div>
                        <div className="font-medium">{consultation.title}</div>
                        <div className="text-sm text-neutral-500">
                          {getPatientName(consultation.patientId)} - {format(new Date(consultation.date), 'dd MMM yyyy', { locale: nl })}
                        </div>
                      </div>
                      <Link 
                        href={`/patients/${consultation.patientId}`} 
                        className="text-sm text-primary hover:underline mt-1 md:mt-0"
                      >
                        Bekijk patiënt
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-neutral-500 text-center py-4">
                Geen recente consultaties
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-medium flex items-center">
              <FileCheck className="mr-2 h-5 w-5" />
              Recente Voorschriften
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentPrescriptions.length > 0 ? (
              <div className="space-y-4">
                {recentPrescriptions.map((prescription) => (
                  <div 
                    key={prescription.id} 
                    className="border-b border-neutral-100 last:border-0 pb-3 last:pb-0"
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between">
                      <div>
                        <div className="font-medium">{prescription.medicationName}</div>
                        <div className="text-sm text-neutral-500">
                          {getPatientName(prescription.patientId)} - {format(new Date(prescription.date), 'dd MMM yyyy', { locale: nl })}
                        </div>
                      </div>
                      {prescription.pdfUrl && (
                        <a 
                          href={prescription.pdfUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-sm text-primary hover:underline mt-1 md:mt-0 flex items-center"
                        >
                          <span className="material-icons text-sm mr-1">file_download</span>
                          PDF
                        </a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-neutral-500 text-center py-4">
                Geen recente voorschriften
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DashboardPage;

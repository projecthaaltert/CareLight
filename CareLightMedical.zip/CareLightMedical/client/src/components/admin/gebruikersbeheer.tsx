import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { User, insertUserSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";
import { Loader2, Plus, UserPlus, Pencil, Trash2 } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";

// Schema voor het gebruikersformulier
const userFormSchema = insertUserSchema.extend({
  password: z.string().min(6, "Wachtwoord moet minimaal 6 karakters bevatten"),
  confirmPassword: z.string()
}).refine(data => data.password === data.confirmPassword, {
  message: "Wachtwoorden komen niet overeen",
  path: ["confirmPassword"]
});

type UserFormValues = z.infer<typeof userFormSchema>;

export default function Gebruikersbeheer() {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  // Haal gebruikers op
  const { data: users, isLoading } = useQuery<User[]>({
    queryKey: ['/api/admin/users'],
  });

  // Default waarden voor het formulier
  const defaultValues: Partial<UserFormValues> = {
    username: "",
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
    role: "doctor",
    specialty: "",
    registrationNumber: ""
  };

  const form = useForm<UserFormValues>({
    resolver: zodResolver(userFormSchema),
    defaultValues,
  });

  // Gebruiker aanmaken
  const createUserMutation = useMutation({
    mutationFn: async (data: UserFormValues) => {
      const userData = {
        username: data.username,
        password: data.password,
        fullName: data.fullName,
        email: data.email,
        role: data.role,
        specialty: data.specialty,
        registrationNumber: data.registrationNumber
      };

      const response = await apiRequest(
        "POST",
        "/api/admin/users",
        userData
      );
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Gebruiker aangemaakt",
        description: "De gebruiker is succesvol aangemaakt.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
      form.reset(defaultValues);
      setIsDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Fout",
        description: `Gebruiker aanmaken mislukt: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Gebruiker verwijderen
  const deleteUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      const response = await apiRequest(
        "DELETE",
        `/api/admin/users/${userId}`,
      );
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Gebruiker verwijderd",
        description: "De gebruiker is succesvol verwijderd.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
    },
    onError: (error) => {
      toast({
        title: "Fout",
        description: `Gebruiker verwijderen mislukt: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  function onSubmit(data: UserFormValues) {
    createUserMutation.mutate(data);
  }

  const isSubmitting = createUserMutation.isPending;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold tracking-tight">Gebruikersbeheer</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <UserPlus className="mr-2 h-4 w-4" />
              Nieuwe gebruiker
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Nieuwe gebruiker aanmaken</DialogTitle>
              <DialogDescription>
                Voeg een nieuwe gebruiker toe aan het systeem. Vul alle vereiste velden in.
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Gebruikersnaam</FormLabel>
                      <FormControl>
                        <Input placeholder="Voer gebruikersnaam in" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="fullName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Volledige naam</FormLabel>
                      <FormControl>
                        <Input placeholder="Voer volledige naam in" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>E-mail</FormLabel>
                      <FormControl>
                        <Input placeholder="Voer e-mailadres in" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Wachtwoord</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="••••••" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Bevestig wachtwoord</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="••••••" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="role"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Rol</FormLabel>
                      <FormControl>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Selecteer een rol" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="admin">Beheerder</SelectItem>
                            <SelectItem value="doctor">Arts</SelectItem>
                            <SelectItem value="nurse">Verpleegkundige</SelectItem>
                            <SelectItem value="receptionist">Receptionist</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="specialty"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Specialisatie</FormLabel>
                      <FormControl>
                        <Input placeholder="Bijv. Cardiologie, Huisarts" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="registrationNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Registratienummer</FormLabel>
                      <FormControl>
                        <Input placeholder="Bijv. RIZIV-nummer" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                    {isSubmitting ? "Bezig met aanmaken..." : "Gebruiker aanmaken"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Gebruikerslijst</CardTitle>
          <CardDescription>
            Alle gebruikers in het systeem. Beheerders kunnen gebruikers toevoegen, bewerken en verwijderen.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-6">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Gebruikersnaam</TableHead>
                  <TableHead>Naam</TableHead>
                  <TableHead>E-mail</TableHead>
                  <TableHead>Rol</TableHead>
                  <TableHead>Specialisatie</TableHead>
                  <TableHead>Registratienummer</TableHead>
                  <TableHead className="text-right">Acties</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users && users.length > 0 ? (
                  users.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>{user.username}</TableCell>
                      <TableCell>{user.fullName}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        {user.role === 'admin' && 'Beheerder'}
                        {user.role === 'doctor' && 'Arts'}
                        {user.role === 'nurse' && 'Verpleegkundige'}
                        {user.role === 'receptionist' && 'Receptionist'}
                      </TableCell>
                      <TableCell>{user.specialty || '-'}</TableCell>
                      <TableCell>{user.registrationNumber || '-'}</TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => deleteUserMutation.mutate(user.id)}
                          disabled={user.username === 'emiovdp'} // Bescherm admin gebruiker
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-4 text-muted-foreground">
                      Geen gebruikers gevonden. Voeg een nieuwe gebruiker toe.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
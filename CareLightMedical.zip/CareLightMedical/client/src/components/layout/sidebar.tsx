import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { 
  LayoutDashboard, 
  Users, 
  Calendar, 
  FileText, 
  ClipboardList,
  Settings, 
  UserCog,
  HelpCircle
} from "lucide-react";

interface NavItemProps {
  href: string;
  icon: React.ReactNode;
  label: string;
  active?: boolean;
}

function NavItem({ href, icon, label, active }: NavItemProps) {
  const [, navigate] = useLocation();
  
  return (
    <li>
      <a 
        href={href}
        onClick={(e) => {
          e.preventDefault();
          navigate(href);
        }}
        className={cn(
          "flex items-center px-6 py-3 text-gray-700 hover:bg-primary-50 transition-all",
          active && "bg-primary-50 border-l-3 border-primary-500 font-medium text-primary-500"
        )}
      >
        <span className="mr-3">{icon}</span>
        {label}
      </a>
    </li>
  );
}

export default function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();
  
  const isDoctor = user?.role === 'doctor';
  const isAdmin = user?.role === 'admin';
  
  const mainNavItems = [
    { 
      href: "/", 
      icon: <LayoutDashboard className="h-5 w-5" />, 
      label: "Dashboard",
      active: location === "/"
    },
    { 
      href: "/patients", 
      icon: <Users className="h-5 w-5" />, 
      label: "Patients",
      active: location.startsWith("/patients") 
    },
    { 
      href: "/appointments", 
      icon: <Calendar className="h-5 w-5" />, 
      label: "Appointments",
      active: location.startsWith("/appointments") 
    },
    { 
      href: "/prescriptions", 
      icon: <FileText className="h-5 w-5" />, 
      label: "Prescriptions",
      active: location.startsWith("/prescriptions") 
    },
    { 
      href: "/reports", 
      icon: <ClipboardList className="h-5 w-5" />, 
      label: "Medical Reports",
      active: location.startsWith("/reports") 
    }
  ];
  
  const adminNavItems = [
    { 
      href: "/settings", 
      icon: <Settings className="h-5 w-5" />, 
      label: "Settings",
      active: location === "/settings" 
    },
    { 
      href: "/team", 
      icon: <UserCog className="h-5 w-5" />, 
      label: "Team Members",
      active: location === "/team" 
    },
    { 
      href: "/help", 
      icon: <HelpCircle className="h-5 w-5" />, 
      label: "Help & Support",
      active: location === "/help" 
    }
  ];
  
  return (
    <aside className="bg-white border-r border-gray-200 w-64 flex-shrink-0 hidden md:block">
      <nav className="h-full overflow-y-auto py-4">
        <ul>
          <li className="px-4 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wider">
            Main Menu
          </li>
          {mainNavItems.map((item) => (
            <NavItem 
              key={item.href} 
              href={item.href} 
              icon={item.icon} 
              label={item.label} 
              active={item.active}
            />
          ))}
          
          {(isDoctor || isAdmin) && (
            <>
              <li className="px-4 py-2 mt-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                Administration
              </li>
              {adminNavItems.map((item) => (
                <NavItem 
                  key={item.href} 
                  href={item.href} 
                  icon={item.icon} 
                  label={item.label} 
                  active={item.active}
                />
              ))}
            </>
          )}
        </ul>
      </nav>
    </aside>
  );
}

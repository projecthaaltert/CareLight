import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Generate a medical report based on patient data and medical history
export async function generateMedicalReport(
  patientInfo: {
    name: string;
    age: number;
    gender: string;
    medicalHistory: string[];
    currentSymptoms: string;
    vitalSigns?: {
      bloodPressure?: string;
      heartRate?: number;
      temperature?: number;
    };
  }
): Promise<{ content: string; summary: string }> {
  const prompt = `
    Generate a comprehensive medical report for a patient with the following information:
    
    Patient Name: ${patientInfo.name}
    Age: ${patientInfo.age}
    Gender: ${patientInfo.gender}
    
    Medical History:
    ${patientInfo.medicalHistory.map((item) => `- ${item}`).join("\n")}
    
    Current Symptoms:
    ${patientInfo.currentSymptoms}
    
    ${patientInfo.vitalSigns ? `
    Vital Signs:
    - Blood Pressure: ${patientInfo.vitalSigns.bloodPressure || "Not measured"}
    - Heart Rate: ${patientInfo.vitalSigns.heartRate || "Not measured"} bpm
    - Temperature: ${patientInfo.vitalSigns.temperature || "Not measured"} °C
    ` : ''}
    
    Based on this information, generate:
    1. A detailed clinical assessment
    2. Diagnosis or differential diagnoses
    3. Treatment recommendations
    4. Follow-up plan
    
    Format the report in a professional medical style. Also provide a brief summary of the key findings and recommendations.
    
    Reply with a JSON object containing two fields:
    - "content": the detailed medical report
    - "summary": a brief summary of key findings and recommendations
  `;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content);
    return {
      content: result.content,
      summary: result.summary,
    };
  } catch (error) {
    console.error("Error generating medical report:", error);
    throw new Error("Failed to generate medical report. Please try again later.");
  }
}

// Generate prescription recommendations based on patient data and diagnosis
export async function generatePrescriptionRecommendations(
  patientInfo: {
    age: number;
    gender: string;
    diagnosis: string;
    symptoms: string;
    allergies: string[];
    currentMedications: string[];
  }
): Promise<{
  recommendations: Array<{
    medication: string;
    dosage: string;
    frequency: string;
    duration: string;
    warnings: string[];
  }>;
  considerations: string[];
}> {
  const prompt = `
    Generate prescription recommendations for a patient with the following information:
    
    Age: ${patientInfo.age}
    Gender: ${patientInfo.gender}
    Diagnosis: ${patientInfo.diagnosis}
    Symptoms: ${patientInfo.symptoms}
    
    Allergies:
    ${patientInfo.allergies.map((allergy) => `- ${allergy}`).join("\n") || "None reported"}
    
    Current Medications:
    ${patientInfo.currentMedications.map((med) => `- ${med}`).join("\n") || "None"}
    
    Based on this information, provide medication recommendations including dosage, frequency, and duration.
    Also include any warnings or considerations for each medication and general considerations for the patient.
    
    Format your response as a JSON object with the following structure:
    {
      "recommendations": [
        {
          "medication": "Name of medication",
          "dosage": "Recommended dosage",
          "frequency": "How often to take",
          "duration": "How long to take",
          "warnings": ["List of warnings"]
        }
      ],
      "considerations": ["List of general considerations"]
    }
  `;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content);
  } catch (error) {
    console.error("Error generating prescription recommendations:", error);
    throw new Error("Failed to generate prescription recommendations. Please try again later.");
  }
}

// Analyze patient symptoms and provide preliminary diagnosis
export async function analyzeSymptomsForDiagnosis(
  symptoms: string,
  patientAge: number,
  patientGender: string,
  medicalHistory?: string[]
): Promise<{
  possibleDiagnoses: Array<{ condition: string; likelihood: string; description: string }>;
  recommendedTests: string[];
  immediateActions: string[];
}> {
  const prompt = `
    Analyze the following patient symptoms and provide a preliminary diagnosis:
    
    Symptoms: ${symptoms}
    Age: ${patientAge}
    Gender: ${patientGender}
    ${
      medicalHistory
        ? `Medical History:\n${medicalHistory
            .map((item) => `- ${item}`)
            .join("\n")}`
        : ""
    }
    
    Based on this information, provide:
    1. Possible diagnoses with likelihood assessment
    2. Recommended tests or examinations
    3. Immediate actions or precautions
    
    Format your response as a JSON object with the following structure:
    {
      "possibleDiagnoses": [
        {
          "condition": "Name of condition",
          "likelihood": "High/Medium/Low",
          "description": "Brief description of the condition"
        }
      ],
      "recommendedTests": ["List of recommended tests"],
      "immediateActions": ["List of immediate actions to take"]
    }
  `;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content);
  } catch (error) {
    console.error("Error analyzing symptoms:", error);
    throw new Error("Failed to analyze symptoms. Please try again later.");
  }
}

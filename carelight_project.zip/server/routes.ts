import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated, hasRole, hashPassword } from "./auth";
import { generateMedicalReport, generatePrescriptionRecommendations, analyzeSymptomsForDiagnosis } from "./openai";
import { generatePrescriptionPdf, generateReportPdf } from "./pdf";
import { z } from "zod";
import { Patient, Prescription, Consultation as MedicalHistory, Report as MedicalReport, User,
  insertPatientSchema, insertPrescriptionSchema, insertConsultationSchema as insertMedicalHistorySchema, 
  insertReportSchema, insertUserSchema } from "@shared/schema";

// Tijdelijke definities voor ontbrekende schema's en types
interface Insurance {
  id: number;
  provider: string;
  policyNumber: string;
  patientId: number;
  startDate: Date;
  endDate?: Date;
}

interface Appointment {
  id: number;
  patientId: number;
  doctorId: number;
  title: string;
  date: Date;
  startTime: string;
  endTime: string;
  description?: string;
  location?: string;
  status: string;
}

interface HealthMetric {
  id: number;
  patientId: number;
  type: string;
  value: string;
  date: Date;
  notes?: string;
}

// Tijdelijke schema definities
const insertInsuranceSchema = z.object({
  provider: z.string(),
  policyNumber: z.string(),
  patientId: z.number(),
  startDate: z.date(),
  endDate: z.date().optional(),
});

const insertAppointmentSchema = z.object({
  patientId: z.number(),
  doctorId: z.number(),
  title: z.string(),
  date: z.string().or(z.date()),
  startTime: z.string(),
  endTime: z.string(),
  description: z.string().optional(),
  location: z.string().optional(),
  status: z.string().default("scheduled"),
});

const insertHealthMetricSchema = z.object({
  patientId: z.number(),
  type: z.string(),
  value: z.string(),
  date: z.date().or(z.string()),
  notes: z.string().optional(),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication - adds /api/register, /api/login, /api/logout, /api/user
  setupAuth(app);
  
  // Admin routes
  app.get("/api/admin/users", isAuthenticated, hasRole(["admin"]), async (req: Request, res: Response) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Er is een fout opgetreden bij het ophalen van gebruikers" });
    }
  });

  app.post("/api/admin/users", isAuthenticated, hasRole(["admin"]), async (req: Request, res: Response) => {
    try {
      const parseResult = insertUserSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({ message: "Ongeldige gebruikersgegevens", errors: parseResult.error.format() });
      }
      
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ message: "Gebruikersnaam bestaat al" });
      }
      
      // Hash het wachtwoord voordat de gebruiker wordt aangemaakt
      const hashedUserData = {
        ...parseResult.data,
        password: await hashPassword(parseResult.data.password)
      };
      
      const user = await storage.createUser(hashedUserData);
      res.status(201).json(user);
    } catch (error) {
      res.status(500).json({ message: "Er is een fout opgetreden bij het aanmaken van de gebruiker" });
    }
  });
  
  app.delete("/api/admin/users/:id", isAuthenticated, hasRole(["admin"]), async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Controleer of het de admin account is die niet verwijderd mag worden
      const user = await storage.getUser(userId);
      if (user && user.username === "emiovdp") {
        return res.status(403).json({ message: "De hoofdbeheerder kan niet worden verwijderd" });
      }
      
      const success = await storage.deleteUser(userId);
      if (success) {
        res.json({ message: "Gebruiker succesvol verwijderd" });
      } else {
        res.status(404).json({ message: "Gebruiker niet gevonden" });
      }
    } catch (error) {
      res.status(500).json({ message: "Er is een fout opgetreden bij het verwijderen van de gebruiker" });
    }
  });

  // Patients API endpoints
  app.get("/api/patients", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const patients = await storage.getAllPatients();
      res.status(200).json(patients);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve patients" });
    }
  });

  app.get("/api/patients/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid patient ID" });
      }
      
      const patient = await storage.getPatient(id);
      if (!patient) {
        return res.status(404).json({ message: "Patient not found" });
      }
      
      res.status(200).json(patient);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve patient" });
    }
  });

  app.post("/api/patients", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const patientData = insertPatientSchema.parse(req.body);
      const patient = await storage.createPatient(patientData);
      res.status(201).json(patient);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid patient data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create patient" });
    }
  });

  app.put("/api/patients/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid patient ID" });
      }
      
      const patientData = insertPatientSchema.partial().parse(req.body);
      const updatedPatient = await storage.updatePatient(id, patientData);
      
      if (!updatedPatient) {
        return res.status(404).json({ message: "Patient not found" });
      }
      
      res.status(200).json(updatedPatient);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid patient data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update patient" });
    }
  });

  app.delete("/api/patients/:id", isAuthenticated, hasRole(["admin", "doctor"]), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid patient ID" });
      }
      
      const success = await storage.deletePatient(id);
      if (!success) {
        return res.status(404).json({ message: "Patient not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete patient" });
    }
  });

  app.get("/api/patients/search/:nationalId", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const nationalId = req.params.nationalId;
      const patient = await storage.getPatientByNationalId(nationalId);
      
      if (!patient) {
        return res.status(404).json({ message: "Patient not found" });
      }
      
      res.status(200).json(patient);
    } catch (error) {
      res.status(500).json({ message: "Failed to search for patient" });
    }
  });

  // Insurance API endpoints
  app.get("/api/patients/:patientId/insurance", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const patientId = parseInt(req.params.patientId);
      if (isNaN(patientId)) {
        return res.status(400).json({ message: "Invalid patient ID" });
      }
      
      const insurance = await storage.getInsuranceByPatientId(patientId);
      if (!insurance) {
        return res.status(404).json({ message: "Insurance information not found" });
      }
      
      res.status(200).json(insurance);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve insurance information" });
    }
  });

  app.post("/api/patients/:patientId/insurance", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const patientId = parseInt(req.params.patientId);
      if (isNaN(patientId)) {
        return res.status(400).json({ message: "Invalid patient ID" });
      }
      
      const insuranceData = insertInsuranceSchema.parse({ ...req.body, patientId });
      const insurance = await storage.createInsurance(insuranceData);
      
      res.status(201).json(insurance);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid insurance data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create insurance information" });
    }
  });

  app.put("/api/insurance/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid insurance ID" });
      }
      
      const insuranceData = insertInsuranceSchema.partial().parse(req.body);
      const updatedInsurance = await storage.updateInsurance(id, insuranceData);
      
      if (!updatedInsurance) {
        return res.status(404).json({ message: "Insurance information not found" });
      }
      
      res.status(200).json(updatedInsurance);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid insurance data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update insurance information" });
    }
  });

  // Medical History API endpoints
  app.get("/api/patients/:patientId/medical-history", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const patientId = parseInt(req.params.patientId);
      if (isNaN(patientId)) {
        return res.status(400).json({ message: "Invalid patient ID" });
      }
      
      const medicalHistories = await storage.getMedicalHistoriesByPatientId(patientId);
      res.status(200).json(medicalHistories);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve medical history" });
    }
  });

  app.post("/api/patients/:patientId/medical-history", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const patientId = parseInt(req.params.patientId);
      if (isNaN(patientId)) {
        return res.status(400).json({ message: "Invalid patient ID" });
      }
      
      const medicalHistoryData = insertMedicalHistorySchema.parse({ ...req.body, patientId });
      const medicalHistory = await storage.createMedicalHistory(medicalHistoryData);
      
      res.status(201).json(medicalHistory);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid medical history data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create medical history entry" });
    }
  });

  app.put("/api/medical-history/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid medical history ID" });
      }
      
      const medicalHistoryData = insertMedicalHistorySchema.partial().parse(req.body);
      const updatedMedicalHistory = await storage.updateMedicalHistory(id, medicalHistoryData);
      
      if (!updatedMedicalHistory) {
        return res.status(404).json({ message: "Medical history entry not found" });
      }
      
      res.status(200).json(updatedMedicalHistory);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid medical history data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update medical history entry" });
    }
  });

  // Prescription API endpoints
  app.get("/api/patients/:patientId/prescriptions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const patientId = parseInt(req.params.patientId);
      if (isNaN(patientId)) {
        return res.status(400).json({ message: "Invalid patient ID" });
      }
      
      const prescriptions = await storage.getPrescriptionsByPatientId(patientId);
      res.status(200).json(prescriptions);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve prescriptions" });
    }
  });

  app.get("/api/prescriptions/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid prescription ID" });
      }
      
      const prescription = await storage.getPrescription(id);
      if (!prescription) {
        return res.status(404).json({ message: "Prescription not found" });
      }
      
      res.status(200).json(prescription);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve prescription" });
    }
  });

  app.post("/api/patients/:patientId/prescriptions", isAuthenticated, hasRole(["doctor"]), async (req: Request, res: Response) => {
    try {
      const patientId = parseInt(req.params.patientId);
      if (isNaN(patientId)) {
        return res.status(400).json({ message: "Invalid patient ID" });
      }
      
      const prescriptionData = insertPrescriptionSchema.parse({ 
        ...req.body, 
        patientId,
        doctorId: req.user!.id
      });
      
      const prescription = await storage.createPrescription(prescriptionData);
      res.status(201).json(prescription);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid prescription data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create prescription" });
    }
  });

  app.put("/api/prescriptions/:id", isAuthenticated, hasRole(["doctor"]), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid prescription ID" });
      }
      
      const prescriptionData = insertPrescriptionSchema.partial().parse(req.body);
      const updatedPrescription = await storage.updatePrescription(id, prescriptionData);
      
      if (!updatedPrescription) {
        return res.status(404).json({ message: "Prescription not found" });
      }
      
      res.status(200).json(updatedPrescription);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid prescription data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update prescription" });
    }
  });

  app.get("/api/prescriptions/:id/pdf", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid prescription ID" });
      }
      
      const prescription = await storage.getPrescription(id);
      if (!prescription) {
        return res.status(404).json({ message: "Prescription not found" });
      }
      
      const patient = await storage.getPatient(prescription.patientId);
      if (!patient) {
        return res.status(404).json({ message: "Patient not found" });
      }
      
      const doctor = await storage.getUser(prescription.doctorId);
      if (!doctor) {
        return res.status(404).json({ message: "Doctor not found" });
      }
      
      const pdfBytes = await generatePrescriptionPdf({
        patient: {
          name: `${patient.firstName} ${patient.lastName}`,
          dateOfBirth: patient.dateOfBirth.toLocaleDateString(),
          nationalId: patient.nationalId,
          address: patient.address
        },
        doctor: {
          name: doctor.fullName,
          specialization: doctor.specialization || "General Practitioner"
        },
        medication: prescription.medication,
        dosage: prescription.dosage,
        frequency: prescription.frequency,
        startDate: prescription.startDate,
        endDate: prescription.endDate,
        instructions: prescription.instructions
      });
      
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="prescription_${id}.pdf"`);
      res.send(Buffer.from(pdfBytes));
    } catch (error) {
      res.status(500).json({ message: "Failed to generate prescription PDF" });
    }
  });

  // AI Prescription Recommendations
  app.post("/api/ai/prescription-recommendations", isAuthenticated, hasRole(["doctor"]), async (req: Request, res: Response) => {
    try {
      const { age, gender, diagnosis, symptoms, allergies, currentMedications } = req.body;
      
      if (!age || !gender || !diagnosis || !symptoms) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      const recommendations = await generatePrescriptionRecommendations({
        age,
        gender,
        diagnosis,
        symptoms,
        allergies: allergies || [],
        currentMedications: currentMedications || []
      });
      
      res.status(200).json(recommendations);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate prescription recommendations" });
    }
  });

  // Appointment API endpoints
  app.get("/api/patients/:patientId/appointments", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const patientId = parseInt(req.params.patientId);
      if (isNaN(patientId)) {
        return res.status(400).json({ message: "Invalid patient ID" });
      }
      
      const appointments = await storage.getAppointmentsByPatientId(patientId);
      res.status(200).json(appointments);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve appointments" });
    }
  });

  app.get("/api/doctors/:doctorId/appointments", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const doctorId = parseInt(req.params.doctorId);
      if (isNaN(doctorId)) {
        return res.status(400).json({ message: "Invalid doctor ID" });
      }
      
      const appointments = await storage.getAppointmentsByDoctorId(doctorId);
      res.status(200).json(appointments);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve appointments" });
    }
  });

  app.post("/api/patients/:patientId/appointments", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const patientId = parseInt(req.params.patientId);
      if (isNaN(patientId)) {
        return res.status(400).json({ message: "Invalid patient ID" });
      }
      
      const appointmentData = insertAppointmentSchema.parse({ 
        ...req.body, 
        patientId,
        doctorId: parseInt(req.body.doctorId)
      });
      
      const appointment = await storage.createAppointment(appointmentData);
      res.status(201).json(appointment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid appointment data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create appointment" });
    }
  });

  app.put("/api/appointments/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid appointment ID" });
      }
      
      const appointmentData = insertAppointmentSchema.partial().parse(req.body);
      const updatedAppointment = await storage.updateAppointment(id, appointmentData);
      
      if (!updatedAppointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      
      res.status(200).json(updatedAppointment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid appointment data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update appointment" });
    }
  });

  // Medical Report API endpoints
  app.get("/api/patients/:patientId/reports", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const patientId = parseInt(req.params.patientId);
      if (isNaN(patientId)) {
        return res.status(400).json({ message: "Invalid patient ID" });
      }
      
      const reports = await storage.getReportsByPatientId(patientId);
      res.status(200).json(reports);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve medical reports" });
    }
  });

  app.get("/api/reports/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid report ID" });
      }
      
      const report = await storage.getReport(id);
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }
      
      res.status(200).json(report);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve report" });
    }
  });

  app.post("/api/patients/:patientId/reports", isAuthenticated, hasRole(["doctor"]), async (req: Request, res: Response) => {
    try {
      const patientId = parseInt(req.params.patientId);
      if (isNaN(patientId)) {
        return res.status(400).json({ message: "Invalid patient ID" });
      }
      
      const reportData = insertReportSchema.parse({ 
        ...req.body, 
        patientId,
        doctorId: req.user!.id
      });
      
      const report = await storage.createReport(reportData);
      res.status(201).json(report);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid report data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create report" });
    }
  });

  app.get("/api/reports/:id/pdf", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid report ID" });
      }
      
      const report = await storage.getReport(id);
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }
      
      const patient = await storage.getPatient(report.patientId);
      if (!patient) {
        return res.status(404).json({ message: "Patient not found" });
      }
      
      const doctor = await storage.getUser(report.doctorId);
      if (!doctor) {
        return res.status(404).json({ message: "Doctor not found" });
      }
      
      const pdfBytes = await generateReportPdf(
        report,
        doctor,
        patient
      );
      
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="report_${id}.pdf"`);
      res.send(Buffer.from(pdfBytes));
    } catch (error) {
      res.status(500).json({ message: "Failed to generate report PDF" });
    }
  });

  // AI Medical Report Generation
  app.post("/api/ai/generate-report", isAuthenticated, hasRole(["doctor"]), async (req: Request, res: Response) => {
    try {
      const { patientInfo } = req.body;
      
      if (!patientInfo || !patientInfo.name || !patientInfo.age || !patientInfo.gender || !patientInfo.currentSymptoms) {
        return res.status(400).json({ message: "Missing required patient information" });
      }
      
      const report = await generateMedicalReport(patientInfo);
      res.status(200).json(report);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate AI medical report" });
    }
  });

  // AI Symptom Analysis
  app.post("/api/ai/analyze-symptoms", isAuthenticated, hasRole(["doctor"]), async (req: Request, res: Response) => {
    try {
      const { symptoms, patientAge, patientGender, medicalHistory } = req.body;
      
      if (!symptoms || !patientAge || !patientGender) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      const analysis = await analyzeSymptomsForDiagnosis(
        symptoms,
        patientAge,
        patientGender,
        medicalHistory
      );
      
      res.status(200).json(analysis);
    } catch (error) {
      res.status(500).json({ message: "Failed to analyze symptoms" });
    }
  });

  // Health Metrics API endpoints
  app.get("/api/patients/:patientId/health-metrics", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const patientId = parseInt(req.params.patientId);
      if (isNaN(patientId)) {
        return res.status(400).json({ message: "Invalid patient ID" });
      }
      
      const type = req.query.type as string | undefined;
      const metrics = await storage.getHealthMetricsByPatientId(patientId, type);
      
      res.status(200).json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve health metrics" });
    }
  });

  app.post("/api/patients/:patientId/health-metrics", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const patientId = parseInt(req.params.patientId);
      if (isNaN(patientId)) {
        return res.status(400).json({ message: "Invalid patient ID" });
      }
      
      const metricData = insertHealthMetricSchema.parse({ 
        ...req.body, 
        patientId 
      });
      
      const metric = await storage.createHealthMetric(metricData);
      res.status(201).json(metric);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid health metric data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create health metric" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

import { 
  User, 
  InsertUser, 
  Patient, 
  InsertPatient,
  Medication,
  InsertMedication,
  Consultation,
  InsertConsultation,
  Prescription,
  InsertPrescription,
  Report,
  InsertReport
} from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  deleteUser(id: number): Promise<boolean>;

  // Patient methods
  getPatient(id: number): Promise<Patient | undefined>;
  getPatientByRRN(rrn: string): Promise<Patient | undefined>;
  getAllPatients(): Promise<Patient[]>;
  createPatient(patient: InsertPatient): Promise<Patient>;
  updatePatient(id: number, patient: InsertPatient): Promise<Patient | undefined>;
  deletePatient(id: number): Promise<boolean>;

  // Medication methods
  getMedication(id: number): Promise<Medication | undefined>;
  getAllMedications(): Promise<Medication[]>;
  createMedication(medication: InsertMedication): Promise<Medication>;

  // Consultation methods
  getConsultation(id: number): Promise<Consultation | undefined>;
  getAllConsultations(): Promise<Consultation[]>;
  getConsultationsByPatientId(patientId: number): Promise<Consultation[]>;
  createConsultation(consultation: InsertConsultation): Promise<Consultation>;

  // Prescription methods
  getPrescription(id: number): Promise<Prescription | undefined>;
  getAllPrescriptions(): Promise<Prescription[]>;
  getPrescriptionsByPatientId(patientId: number): Promise<Prescription[]>;
  createPrescription(prescription: InsertPrescription): Promise<Prescription>;
  updatePrescriptionPdf(id: number, pdfUrl: string): Promise<void>;

  // Report methods
  getReport(id: number): Promise<Report | undefined>;
  getAllReports(): Promise<Report[]>;
  getReportsByPatientId(patientId: number): Promise<Report[]>;
  createReport(report: InsertReport): Promise<Report>;
  updateReportPdf(id: number, pdfUrl: string): Promise<void>;

  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private patients: Map<number, Patient>;
  private medications: Map<number, Medication>;
  private consultations: Map<number, Consultation>;
  private prescriptions: Map<number, Prescription>;
  private reports: Map<number, Report>;
  
  private userIdCounter: number;
  private patientIdCounter: number;
  private medicationIdCounter: number;
  private consultationIdCounter: number;
  private prescriptionIdCounter: number;
  private reportIdCounter: number;
  
  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.patients = new Map();
    this.medications = new Map();
    this.consultations = new Map();
    this.prescriptions = new Map();
    this.reports = new Map();
    
    this.userIdCounter = 1;
    this.patientIdCounter = 1;
    this.medicationIdCounter = 1;
    this.consultationIdCounter = 1;
    this.prescriptionIdCounter = 1;
    this.reportIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // Clear expired sessions every 24h
    });
    
    // Initialize with sample data for medications
    this.initSampleMedications();
  }

  private initSampleMedications() {
    const sampleMedications: InsertMedication[] = [
      { name: "Metformine", dosage: "500mg", form: "tablet", description: "Voor diabetes type 2" },
      { name: "Simvastatine", dosage: "40mg", form: "tablet", description: "Voor cholesterolverlaging" },
      { name: "Omeprazol", dosage: "20mg", form: "capsule", description: "Voor maagzuurremmers" },
      { name: "Amlodipine", dosage: "5mg", form: "tablet", description: "Voor hoge bloeddruk" },
      { name: "Paracetamol", dosage: "500mg", form: "tablet", description: "Pijnstiller" }
    ];
    
    sampleMedications.forEach(med => {
      this.createMedication(med);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const createdAt = new Date();
    // Zorg ervoor dat role altijd een waarde heeft (default: 'doctor')
    const role = insertUser.role || 'doctor';
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt,
      role,
      specialty: insertUser.specialty || null,
      registrationNumber: insertUser.registrationNumber || null
    };
    this.users.set(id, user);
    return user;
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }

  // Patient methods
  async getPatient(id: number): Promise<Patient | undefined> {
    return this.patients.get(id);
  }

  async getPatientByRRN(rrn: string): Promise<Patient | undefined> {
    return Array.from(this.patients.values()).find(
      (patient) => patient.rijksregisternummer === rrn
    );
  }

  async getAllPatients(): Promise<Patient[]> {
    return Array.from(this.patients.values());
  }

  async createPatient(insertPatient: InsertPatient): Promise<Patient> {
    const id = this.patientIdCounter++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const patient: Patient = { ...insertPatient, id, createdAt, updatedAt };
    this.patients.set(id, patient);
    return patient;
  }

  async updatePatient(id: number, data: InsertPatient): Promise<Patient | undefined> {
    const existingPatient = this.patients.get(id);
    
    if (!existingPatient) {
      return undefined;
    }
    
    const updatedPatient: Patient = {
      ...existingPatient,
      ...data,
      id,
      updatedAt: new Date()
    };
    
    this.patients.set(id, updatedPatient);
    return updatedPatient;
  }

  async deletePatient(id: number): Promise<boolean> {
    return this.patients.delete(id);
  }

  // Medication methods
  async getMedication(id: number): Promise<Medication | undefined> {
    return this.medications.get(id);
  }

  async getAllMedications(): Promise<Medication[]> {
    return Array.from(this.medications.values());
  }

  async createMedication(insertMedication: InsertMedication): Promise<Medication> {
    const id = this.medicationIdCounter++;
    const createdAt = new Date();
    const medication: Medication = { ...insertMedication, id, createdAt };
    this.medications.set(id, medication);
    return medication;
  }

  // Consultation methods
  async getConsultation(id: number): Promise<Consultation | undefined> {
    return this.consultations.get(id);
  }

  async getAllConsultations(): Promise<Consultation[]> {
    return Array.from(this.consultations.values());
  }

  async getConsultationsByPatientId(patientId: number): Promise<Consultation[]> {
    return Array.from(this.consultations.values()).filter(
      (consultation) => consultation.patientId === patientId
    );
  }

  async createConsultation(insertConsultation: InsertConsultation): Promise<Consultation> {
    const id = this.consultationIdCounter++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const consultation: Consultation = { ...insertConsultation, id, createdAt, updatedAt };
    this.consultations.set(id, consultation);
    return consultation;
  }

  // Prescription methods
  async getPrescription(id: number): Promise<Prescription | undefined> {
    return this.prescriptions.get(id);
  }

  async getAllPrescriptions(): Promise<Prescription[]> {
    return Array.from(this.prescriptions.values());
  }

  async getPrescriptionsByPatientId(patientId: number): Promise<Prescription[]> {
    return Array.from(this.prescriptions.values()).filter(
      (prescription) => prescription.patientId === patientId
    );
  }

  async createPrescription(insertPrescription: InsertPrescription): Promise<Prescription> {
    const id = this.prescriptionIdCounter++;
    const createdAt = new Date();
    const prescription: Prescription = { 
      ...insertPrescription, 
      id, 
      createdAt,
      pdfUrl: undefined 
    };
    this.prescriptions.set(id, prescription);
    return prescription;
  }

  async updatePrescriptionPdf(id: number, pdfUrl: string): Promise<void> {
    const prescription = this.prescriptions.get(id);
    if (prescription) {
      prescription.pdfUrl = pdfUrl;
      this.prescriptions.set(id, prescription);
    }
  }

  // Report methods
  async getReport(id: number): Promise<Report | undefined> {
    return this.reports.get(id);
  }

  async getAllReports(): Promise<Report[]> {
    return Array.from(this.reports.values());
  }

  async getReportsByPatientId(patientId: number): Promise<Report[]> {
    return Array.from(this.reports.values()).filter(
      (report) => report.patientId === patientId
    );
  }

  async createReport(insertReport: InsertReport): Promise<Report> {
    const id = this.reportIdCounter++;
    const createdAt = new Date();
    const report: Report = { 
      ...insertReport, 
      id, 
      createdAt,
      pdfUrl: undefined 
    };
    this.reports.set(id, report);
    return report;
  }

  async updateReportPdf(id: number, pdfUrl: string): Promise<void> {
    const report = this.reports.get(id);
    if (report) {
      report.pdfUrl = pdfUrl;
      this.reports.set(id, report);
    }
  }
}

// Import de DatabaseStorage
import { DatabaseStorage } from "./storage.db";

// Gebruik DatabaseStorage in plaats van MemStorage
export const storage = new DatabaseStorage();

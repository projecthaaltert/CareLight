import { pgTable, text, serial, integer, boolean, date, timestamp, pgEnum, varchar } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users (doctors, healthcare providers)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  role: text("role").notNull().default("doctor"), // doctor, nurse, admin
  specialty: text("specialty"),
  registrationNumber: text("registration_number"),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  email: true,
  role: true,
  specialty: true,
  registrationNumber: true
});

// Patients
export const patients = pgTable("patients", {
  id: serial("id").primaryKey(),
  rijksregisternummer: text("rijksregisternummer").unique(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  birthDate: date("birth_date").notNull(),
  gender: text("gender").notNull(),
  address: text("address"),
  city: text("city"),
  postalCode: text("postal_code"),
  phoneNumber: text("phone_number"),
  email: text("email"),
  bloodType: text("blood_type"),
  primaryDoctor: text("primary_doctor"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const insertPatientSchema = createInsertSchema(patients).pick({
  rijksregisternummer: true,
  firstName: true,
  lastName: true,
  birthDate: true,
  gender: true,
  address: true,
  city: true,
  postalCode: true,
  phoneNumber: true,
  email: true,
  bloodType: true,
  primaryDoctor: true
});

// Medications
export const medications = pgTable("medications", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  dosage: text("dosage").notNull(),
  form: text("form").notNull(), // tablet, liquid, etc.
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertMedicationSchema = createInsertSchema(medications).pick({
  name: true,
  dosage: true,
  form: true,
  description: true
});

// Consultations
export const consultations = pgTable("consultations", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull(),
  doctorId: integer("doctor_id").notNull(),
  title: text("title").notNull(),
  date: date("date").notNull(),
  time: text("time").notNull(),
  type: text("type").notNull(), // routine, follow-up, emergency, initial
  symptoms: text("symptoms"),
  diagnosis: text("diagnosis"),
  treatment: text("treatment"),
  notes: text("notes"),
  tags: text("tags").array(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const insertConsultationSchema = createInsertSchema(consultations).pick({
  patientId: true,
  doctorId: true,
  title: true,
  date: true,
  time: true,
  type: true,
  symptoms: true,
  diagnosis: true,
  treatment: true,
  notes: true,
  tags: true
});

// Prescriptions
export const prescriptions = pgTable("prescriptions", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull(),
  doctorId: integer("doctor_id").notNull(),
  medicationName: text("medication_name").notNull(),
  dosage: text("dosage").notNull(),
  quantity: integer("quantity").notNull(),
  quantityUnit: text("quantity_unit").notNull(), // tablets, ml, etc.
  instructions: text("instructions").notNull(),
  duration: integer("duration"),
  durationUnit: text("duration_unit"), // days, weeks, months
  reason: text("reason"),
  date: date("date").notNull(),
  pdfUrl: text("pdf_url"),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertPrescriptionSchema = createInsertSchema(prescriptions).pick({
  patientId: true,
  doctorId: true,
  medicationName: true,
  dosage: true,
  quantity: true,
  quantityUnit: true,
  instructions: true,
  duration: true,
  durationUnit: true,
  reason: true,
  date: true
});

// Medical Reports
export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull(),
  doctorId: integer("doctor_id").notNull(),
  consultationId: integer("consultation_id"),
  title: text("title").notNull(),
  content: text("content").notNull(),
  aiGenerated: boolean("ai_generated").default(false),
  date: date("date").notNull(),
  pdfUrl: text("pdf_url"),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertReportSchema = createInsertSchema(reports).pick({
  patientId: true,
  doctorId: true,
  consultationId: true,
  title: true,
  content: true,
  aiGenerated: true,
  date: true
});

// Definieer relaties tussen tabellen
export const usersRelations = relations(users, ({ many }) => ({
  prescriptions: many(prescriptions, { relationName: "doctor_prescriptions" }),
  consultations: many(consultations, { relationName: "doctor_consultations" }),
  reports: many(reports, { relationName: "doctor_reports" })
}));

export const patientsRelations = relations(patients, ({ many }) => ({
  prescriptions: many(prescriptions),
  consultations: many(consultations),
  reports: many(reports)
}));

export const consultationsRelations = relations(consultations, ({ one }) => ({
  patient: one(patients, {
    fields: [consultations.patientId],
    references: [patients.id]
  }),
  doctor: one(users, {
    fields: [consultations.doctorId],
    references: [users.id],
    relationName: "doctor_consultations"
  })
}));

export const prescriptionsRelations = relations(prescriptions, ({ one }) => ({
  patient: one(patients, {
    fields: [prescriptions.patientId],
    references: [patients.id]
  }),
  doctor: one(users, {
    fields: [prescriptions.doctorId],
    references: [users.id],
    relationName: "doctor_prescriptions"
  })
}));

export const reportsRelations = relations(reports, ({ one }) => ({
  patient: one(patients, {
    fields: [reports.patientId],
    references: [patients.id]
  }),
  doctor: one(users, {
    fields: [reports.doctorId],
    references: [users.id],
    relationName: "doctor_reports"
  }),
  consultation: one(consultations, {
    fields: [reports.consultationId],
    references: [consultations.id]
  })
}));

// Define all types exported from the schema
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertPatient = z.infer<typeof insertPatientSchema>;
export type Patient = typeof patients.$inferSelect;

export type InsertMedication = z.infer<typeof insertMedicationSchema>;
export type Medication = typeof medications.$inferSelect;

export type InsertConsultation = z.infer<typeof insertConsultationSchema>;
export type Consultation = typeof consultations.$inferSelect;

export type InsertPrescription = z.infer<typeof insertPrescriptionSchema>;
export type Prescription = typeof prescriptions.$inferSelect;

export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reports.$inferSelect;

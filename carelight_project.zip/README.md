# Carelight - Medisch Dossierbeheer Systeem

## Beschrijving
Carelight is een uitgebreid medisch dossierbeheer systeem dat zorgverleners in staat stelt om patiëntgegevens te beheren.

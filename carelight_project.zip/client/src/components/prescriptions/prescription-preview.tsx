import { Patient, Prescription } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Download, Printer } from "lucide-react";
import { format } from "date-fns";
import { nl } from "date-fns/locale";

interface PrescriptionPreviewProps {
  prescription: Prescription;
  patient: Patient;
  onClose: () => void;
}

const PrescriptionPreview: React.FC<PrescriptionPreviewProps> = ({ 
  prescription, 
  patient, 
  onClose 
}) => {
  const { user } = useAuth();
  
  const handlePrint = () => {
    window.print();
  };

  return (
    <div>
      <div className="border border-neutral-200 rounded-md p-6 print-only">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-xl font-bold text-neutral-800">Carelight Medisch Centrum</h3>
            <p className="text-neutral-600">Medische Laan 123, 1234 AB Amsterdam</p>
            <p className="text-neutral-600">Tel: +31 20 123 4567</p>
          </div>
          <div className="text-right">
            <p className="font-medium">Voorschriftnummer: RX-{prescription.id}</p>
            <p>Datum: {format(new Date(prescription.date), 'dd-MM-yyyy')}</p>
          </div>
        </div>
        
        <div className="border-t border-b border-neutral-300 my-6 py-4">
          <div className="flex justify-between">
            <div>
              <p className="font-medium">Patiënt</p>
              <p className="text-neutral-800">{patient.firstName} {patient.lastName}</p>
              <p className="text-neutral-600">Geb.datum: {format(new Date(patient.birthDate), 'dd-MM-yyyy')}</p>
              <p className="text-neutral-600">RRN: {patient.rijksregisternummer || 'Niet geregistreerd'}</p>
            </div>
            <div className="text-right">
              <p className="font-medium">Voorschrijvend arts</p>
              <p className="text-neutral-800">{user?.fullName}</p>
              <p className="text-neutral-600">RIZIV-nummer: {user?.registrationNumber || 'Niet geregistreerd'}</p>
            </div>
          </div>
        </div>
        
        <div className="mb-6">
          <h4 className="text-lg font-medium mb-3">Voorgeschreven medicatie</h4>
          <div className="border-l-4 border-primary pl-4 py-2">
            <p className="font-bold text-lg">{prescription.medicationName}</p>
            <p className="text-neutral-800"><span className="font-medium">Dosering:</span> {prescription.dosage}</p>
            <p className="text-neutral-800"><span className="font-medium">Hoeveelheid:</span> {prescription.quantity} {prescription.quantityUnit}</p>
            <p className="text-neutral-800"><span className="font-medium">Gebruik:</span> {prescription.instructions}</p>
            {prescription.duration && (
              <p className="text-neutral-800"><span className="font-medium">Duur:</span> {prescription.duration} {prescription.durationUnit}</p>
            )}
            {prescription.reason && (
              <p className="text-neutral-800"><span className="font-medium">Reden:</span> {prescription.reason}</p>
            )}
          </div>
        </div>
        
        <div className="mb-6">
          <h4 className="text-lg font-medium mb-2">Opmerkingen</h4>
          <p className="text-neutral-700">Neem de medicatie zoals voorgeschreven. Niet gebruiken in combinatie met alcohol.</p>
        </div>
        
        <div className="mt-8 pt-8 border-t border-neutral-300">
          <div className="flex justify-between">
            <div>
              <p className="text-sm text-neutral-500">Handtekening arts</p>
              <div className="h-16 w-40 border-b border-neutral-400 mt-6"></div>
            </div>
            <div>
              <p className="text-sm text-neutral-500">Stempel</p>
              <div className="h-16 w-40 border border-dashed border-neutral-400 mt-2 rounded-md"></div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex justify-end mt-6">
        <Button
          variant="outline"
          onClick={onClose}
          className="mr-3"
        >
          Sluiten
        </Button>
        <Button
          variant="outline"
          className="flex items-center mr-3"
          onClick={handlePrint}
        >
          <Printer className="h-4 w-4 mr-2" />
          Afdrukken
        </Button>
        {prescription.pdfUrl && (
          <Button
            className="flex items-center"
            asChild
          >
            <a 
              href={prescription.pdfUrl} 
              target="_blank" 
              rel="noopener noreferrer"
            >
              <Download className="h-4 w-4 mr-2" />
              PDF downloaden
            </a>
          </Button>
        )}
      </div>
    </div>
  );
};

export default PrescriptionPreview;

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { insertPrescriptionSchema, Patient } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Loader2, Lightbulb } from "lucide-react";

interface PrescriptionFormProps {
  patientId: number;
  onSuccess?: () => void;
  onCancel?: () => void;
}

// Extend prescription schema for form validation
const prescriptionFormSchema = insertPrescriptionSchema
  .omit({ patientId: true, doctorId: true }) // These will be added server-side
  .extend({
    startDate: z.string().min(1, "Start date is required"),
    endDate: z.string().optional(),
    duration: z.number().optional(),
    durationType: z.enum(["days", "weeks", "months"]).optional(),
    useAIRecommendations: z.boolean().default(false),
  });

type PrescriptionFormValues = z.infer<typeof prescriptionFormSchema>;

// Mock medications for dropdown
const commonMedications = [
  { value: "paracetamol", label: "Paracetamol" },
  { value: "ibuprofen", label: "Ibuprofen" },
  { value: "amoxicillin", label: "Amoxicillin" },
  { value: "lisinopril", label: "Lisinopril" },
  { value: "metformin", label: "Metformin" },
  { value: "atorvastatin", label: "Atorvastatin" },
  { value: "omeprazole", label: "Omeprazole" },
  { value: "aspirin", label: "Aspirin" },
  { value: "morphine", label: "Morphine" },
  { value: "insulin", label: "Insulin" },
];

export default function PrescriptionForm({ patientId, onSuccess, onCancel }: PrescriptionFormProps) {
  const { toast } = useToast();
  const { user } = useAuth();

  // Fetch patient data to use for AI recommendations
  const { data: patient, isLoading: isLoadingPatient } = useQuery<Patient>({
    queryKey: ['/api/patients', patientId],
    enabled: !!patientId,
  });

  // Default values for the form
  const defaultValues: Partial<PrescriptionFormValues> = {
    medication: "",
    dosage: "",
    frequency: "",
    startDate: new Date().toISOString().split('T')[0],
    endDate: "",
    instructions: "",
    allowRefill: false,
    allowGenericSubstitute: true,
    status: "active",
    useAIRecommendations: false,
  };

  const form = useForm<PrescriptionFormValues>({
    resolver: zodResolver(prescriptionFormSchema),
    defaultValues,
  });

  // AI recommendations mutation
  const aiRecommendationsMutation = useMutation({
    mutationFn: async (data: {
      age: number;
      gender: string;
      diagnosis: string;
      symptoms: string;
      allergies: string[];
      currentMedications: string[];
    }) => {
      const response = await apiRequest(
        "POST",
        "/api/ai/prescription-recommendations",
        data
      );
      return await response.json();
    },
    onSuccess: (data) => {
      // If we have recommendations and the first one is valid
      if (data.recommendations && data.recommendations.length > 0) {
        const recommendation = data.recommendations[0];
        
        // Update the form with AI recommendations
        form.setValue("medication", recommendation.medication);
        form.setValue("dosage", recommendation.dosage);
        form.setValue("frequency", recommendation.frequency);
        
        // Add warnings to instructions
        const warningText = recommendation.warnings.length > 0 
          ? "\n\nWarnings: " + recommendation.warnings.join(", ") 
          : "";
        
        form.setValue("instructions", 
          `${form.getValues("instructions") || ""}${warningText}`
        );
        
        toast({
          title: "AI Recommendations Applied",
          description: "The form has been updated with AI-suggested values.",
        });
      }
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to get AI recommendations: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Create prescription mutation
  const createPrescriptionMutation = useMutation({
    mutationFn: async (data: PrescriptionFormValues) => {
      // Convert form data to the format expected by the API
      const prescriptionData = {
        ...data,
        patientId,
        startDate: new Date(data.startDate),
        endDate: data.endDate ? new Date(data.endDate) : undefined,
      };

      // Remove form-specific fields
      delete (prescriptionData as any).duration;
      delete (prescriptionData as any).durationType;
      delete (prescriptionData as any).useAIRecommendations;

      const response = await apiRequest(
        "POST",
        `/api/patients/${patientId}/prescriptions`,
        prescriptionData
      );
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Prescription created",
        description: "The prescription has been successfully created.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'prescriptions'] });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create prescription: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Watch for changes to calculate end date
  const duration = form.watch("duration");
  const durationType = form.watch("durationType");
  const startDate = form.watch("startDate");
  const useAIRecommendations = form.watch("useAIRecommendations");

  // Update end date when duration changes
  const updateEndDate = () => {
    if (duration && durationType && startDate) {
      const start = new Date(startDate);
      const end = new Date(start);
      
      switch (durationType) {
        case "days":
          end.setDate(start.getDate() + duration);
          break;
        case "weeks":
          end.setDate(start.getDate() + (duration * 7));
          break;
        case "months":
          end.setMonth(start.getMonth() + duration);
          break;
      }
      
      form.setValue("endDate", end.toISOString().split('T')[0]);
    }
  };

  // Handle AI recommendations
  const handleAIRecommendations = () => {
    if (!patient) return;
    
    // Get diagnosis from form
    const diagnosis = form.getValues("instructions")?.split('\n')[0] || "";
    const symptoms = form.getValues("instructions")?.split('\n')[1] || "";
    
    aiRecommendationsMutation.mutate({
      age: new Date().getFullYear() - new Date(patient.dateOfBirth).getFullYear(),
      gender: patient.gender,
      diagnosis,
      symptoms,
      allergies: patient.allergies || [],
      currentMedications: [], // We don't have this data in the form
    });
  };

  // On duration change
  form.watch(() => {
    if (duration && durationType && startDate) {
      updateEndDate();
    }
  });

  function onSubmit(data: PrescriptionFormValues) {
    createPrescriptionMutation.mutate(data);
  }

  const isAiLoading = aiRecommendationsMutation.isPending;
  const isSubmitting = createPrescriptionMutation.isPending;

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="medication"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Medication</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select medication" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {commonMedications.map((med) => (
                      <SelectItem key={med.value} value={med.value}>
                        {med.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="flex items-center gap-2">
            <FormField
              control={form.control}
              name="dosage"
              render={({ field }) => (
                <FormItem className="flex-1">
                  <FormLabel>Dosage</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. 500mg" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>

        <FormField
          control={form.control}
          name="frequency"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Treatment Plan</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="Once daily, morning">Once daily, morning</SelectItem>
                  <SelectItem value="Once daily, evening">Once daily, evening</SelectItem>
                  <SelectItem value="Twice daily, with meals">Twice daily, with meals</SelectItem>
                  <SelectItem value="Three times daily, after meals">Three times daily, after meals</SelectItem>
                  <SelectItem value="Four times daily">Four times daily</SelectItem>
                  <SelectItem value="As needed for symptoms">As needed for symptoms</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="startDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Start Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="flex items-end gap-2">
            <FormField
              control={form.control}
              name="duration"
              render={({ field }) => (
                <FormItem className="flex-1">
                  <FormLabel>Duration</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      placeholder="e.g. 30" 
                      {...field}
                      value={field.value || ""}
                      onChange={(e) => {
                        field.onChange(e.target.value ? parseInt(e.target.value) : undefined);
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="durationType"
              render={({ field }) => (
                <FormItem className="flex-1">
                  <FormControl>
                    <Select onValueChange={field.onChange} value={field.value || ""}>
                      <SelectTrigger>
                        <SelectValue placeholder="Unit" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="days">Days</SelectItem>
                        <SelectItem value="weeks">Weeks</SelectItem>
                        <SelectItem value="months">Months</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>

        <FormField
          control={form.control}
          name="endDate"
          render={({ field }) => (
            <FormItem>
              <FormLabel>End Date (Optional)</FormLabel>
              <FormControl>
                <Input type="date" {...field} value={field.value || ""} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="instructions"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Special Instructions</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Additional instructions or diagnosis information..." 
                  className="min-h-[120px]"
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex items-center gap-6">
          <FormField
            control={form.control}
            name="allowRefill"
            render={({ field }) => (
              <FormItem className="flex items-center space-x-2 space-y-0">
                <FormControl>
                  <Checkbox 
                    checked={field.value} 
                    onCheckedChange={field.onChange} 
                  />
                </FormControl>
                <FormLabel className="text-sm font-normal">Allow Refills</FormLabel>
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="allowGenericSubstitute"
            render={({ field }) => (
              <FormItem className="flex items-center space-x-2 space-y-0">
                <FormControl>
                  <Checkbox 
                    checked={field.value} 
                    onCheckedChange={field.onChange} 
                  />
                </FormControl>
                <FormLabel className="text-sm font-normal">Allow Generic Substitute</FormLabel>
              </FormItem>
            )}
          />
        </div>

        {user?.role === 'doctor' && (
          <FormField
            control={form.control}
            name="useAIRecommendations"
            render={({ field }) => (
              <FormItem>
                <div className="flex items-center space-x-2">
                  <FormControl>
                    <Checkbox 
                      checked={field.value} 
                      onCheckedChange={(checked) => {
                        field.onChange(checked);
                        if (checked) {
                          handleAIRecommendations();
                        }
                      }} 
                    />
                  </FormControl>
                  <FormLabel className="text-sm font-medium">Use AI to recommend dosage and frequency</FormLabel>
                </div>
                
                {useAIRecommendations && (
                  <Alert className="mt-2 bg-blue-50 border-blue-200">
                    <Lightbulb className="h-4 w-4 text-blue-600" />
                    <AlertTitle className="text-blue-800">AI Recommendations</AlertTitle>
                    <AlertDescription className="text-blue-700 text-sm">
                      {isAiLoading ? (
                        <div className="flex items-center">
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          Generating recommendations...
                        </div>
                      ) : (
                        "AI will analyze patient data to suggest appropriate medication, dosage, and frequency."
                      )}
                    </AlertDescription>
                  </Alert>
                )}
              </FormItem>
            )}
          />
        )}

        <div className="flex justify-end space-x-3 pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            {isSubmitting ? "Saving..." : "Save Prescription"}
          </Button>
        </div>
      </form>
    </Form>
  );
}

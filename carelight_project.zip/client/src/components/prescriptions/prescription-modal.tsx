import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import PrescriptionForm from "./prescription-form";
import { usePdf } from "@/hooks/use-pdf";
import { toast } from "@/hooks/use-toast";

interface PrescriptionModalProps {
  patientId: number;
  isOpen: boolean;
  onClose: () => void;
}

export default function PrescriptionModal({ patientId, isOpen, onClose }: PrescriptionModalProps) {
  const [newPrescriptionId, setNewPrescriptionId] = useState<number | null>(null);
  const { fetchAndDownloadPdf } = usePdf();
  
  const handleSuccess = (data: any) => {
    setNewPrescriptionId(data?.id || null);
  };
  
  const handleGeneratePdf = () => {
    if (newPrescriptionId) {
      fetchAndDownloadPdf(
        `/api/prescriptions/${newPrescriptionId}/pdf`, 
        `prescription_${newPrescriptionId}.pdf`
      );
    } else {
      toast({
        title: "Error",
        description: "Cannot generate PDF as the prescription hasn't been saved yet.",
        variant: "destructive",
      });
    }
  };
  
  const handleCancel = () => {
    onClose();
    // Reset prescription ID after closing the modal
    setTimeout(() => setNewPrescriptionId(null), 300);
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>New Prescription</DialogTitle>
          <DialogDescription>
            Create a new prescription for the patient
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          <PrescriptionForm 
            patientId={patientId} 
            onSuccess={handleSuccess} 
            onCancel={handleCancel} 
          />
        </div>
        
        <DialogFooter>
          <div className="w-full flex justify-between items-center">
            <Button
              type="button"
              variant="outline"
              onClick={handleCancel}
            >
              Cancel
            </Button>
            
            <div>
              {newPrescriptionId && (
                <Button 
                  variant="default" 
                  className="bg-amber-500 hover:bg-amber-600 ml-2" 
                  onClick={handleGeneratePdf}
                >
                  Generate PDF
                </Button>
              )}
            </div>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

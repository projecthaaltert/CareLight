import { Patient, Report } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Download, Printer } from "lucide-react";
import { format } from "date-fns";
import { nl } from "date-fns/locale";

interface ReportPreviewProps {
  report: Report;
  patient: Patient;
  onClose: () => void;
}

const ReportPreview: React.FC<ReportPreviewProps> = ({ 
  report, 
  patient, 
  onClose 
}) => {
  const { user } = useAuth();
  
  const handlePrint = () => {
    window.print();
  };

  return (
    <div>
      <div className="border border-neutral-200 rounded-md p-6 print-only">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-xl font-bold text-neutral-800">Carelight Medisch Centrum</h3>
            <p className="text-neutral-600">Medische Laan 123, 1234 AB Amsterdam</p>
            <p className="text-neutral-600">Tel: +31 20 123 4567</p>
          </div>
          <div className="text-right">
            <p className="font-medium">Verslagnummer: REP-{report.id}</p>
            <p>Datum: {format(new Date(report.date), 'dd-MM-yyyy')}</p>
          </div>
        </div>
        
        <div className="border-t border-b border-neutral-300 my-6 py-4">
          <div className="flex justify-between">
            <div>
              <p className="font-medium">Patiënt</p>
              <p className="text-neutral-800">{patient.firstName} {patient.lastName}</p>
              <p className="text-neutral-600">Geb.datum: {format(new Date(patient.birthDate), 'dd-MM-yyyy')}</p>
              <p className="text-neutral-600">RRN: {patient.rijksregisternummer || 'Niet geregistreerd'}</p>
            </div>
            <div className="text-right">
              <p className="font-medium">Arts</p>
              <p className="text-neutral-800">{user?.fullName}</p>
              <p className="text-neutral-600">RIZIV-nummer: {user?.registrationNumber || 'Niet geregistreerd'}</p>
            </div>
          </div>
        </div>
        
        <div className="mb-6">
          <h4 className="text-xl font-semibold mb-4 uppercase">{report.title}</h4>
          <div className="prose prose-sm max-w-none">
            {report.content.split('\n').map((paragraph, i) => (
              <p key={i} className="mb-2">{paragraph}</p>
            ))}
          </div>
          
          {report.aiGenerated && (
            <p className="text-sm text-neutral-500 italic mt-6">
              Dit verslag is gegenereerd met behulp van AI.
            </p>
          )}
        </div>
        
        <div className="mt-8 pt-8 border-t border-neutral-300">
          <div className="flex justify-between">
            <div>
              <p className="text-sm text-neutral-500">Handtekening arts</p>
              <div className="h-16 w-40 border-b border-neutral-400 mt-6"></div>
            </div>
            <div>
              <p className="text-sm text-neutral-500">Stempel</p>
              <div className="h-16 w-40 border border-dashed border-neutral-400 mt-2 rounded-md"></div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex justify-end mt-6">
        <Button
          variant="outline"
          onClick={onClose}
          className="mr-3"
        >
          Sluiten
        </Button>
        <Button
          variant="outline"
          className="flex items-center mr-3"
          onClick={handlePrint}
        >
          <Printer className="h-4 w-4 mr-2" />
          Afdrukken
        </Button>
        {report.pdfUrl && (
          <Button
            className="flex items-center"
            asChild
          >
            <a 
              href={report.pdfUrl} 
              target="_blank" 
              rel="noopener noreferrer"
            >
              <Download className="h-4 w-4 mr-2" />
              PDF downloaden
            </a>
          </Button>
        )}
      </div>
    </div>
  );
};

export default ReportPreview;

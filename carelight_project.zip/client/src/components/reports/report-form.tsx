import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { insertReportSchema, Patient, Consultation } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Loader2, Lightbulb, AlertCircle } from "lucide-react";

interface ReportFormProps {
  patientId: number;
  onSuccess?: () => void;
  onCancel?: () => void;
}

// Extend report schema for form validation
const reportFormSchema = insertReportSchema
  .omit({ patientId: true, doctorId: true }) // These will be added server-side
  .extend({
    date: z.string().min(1, "Date is required"),
    useAI: z.boolean().default(false),
    currentSymptoms: z.string().optional(),
    vitalSigns: z.object({
      bloodPressure: z.string().optional(),
      heartRate: z.number().optional(),
      temperature: z.number().optional(),
    }).optional(),
  });

type ReportFormValues = z.infer<typeof reportFormSchema>;

export default function ReportForm({ patientId, onSuccess, onCancel }: ReportFormProps) {
  const { toast } = useToast();
  const { user } = useAuth();

  // Fetch patient data for AI report generation
  const { data: patient } = useQuery<Patient>({
    queryKey: ['/api/patients', patientId],
    enabled: !!patientId,
  });

  // Fetch medical history for AI report generation
  const { data: medicalHistory } = useQuery<MedicalHistory[]>({
    queryKey: ['/api/patients', patientId, 'medical-history'],
    enabled: !!patientId,
  });

  // Default values for the form
  const defaultValues: Partial<ReportFormValues> = {
    title: "",
    content: "",
    date: new Date().toISOString().split('T')[0],
    aiGenerated: false,
    useAI: false,
    currentSymptoms: "",
    vitalSigns: {
      bloodPressure: "",
      heartRate: undefined,
      temperature: undefined,
    },
  };

  const form = useForm<ReportFormValues>({
    resolver: zodResolver(reportFormSchema),
    defaultValues,
  });

  // AI report generation mutation
  const aiReportMutation = useMutation({
    mutationFn: async (data: {
      patientInfo: {
        name: string;
        age: number;
        gender: string;
        medicalHistory: string[];
        currentSymptoms: string;
        vitalSigns?: {
          bloodPressure?: string;
          heartRate?: number;
          temperature?: number;
        };
      }
    }) => {
      const response = await apiRequest(
        "POST",
        "/api/ai/generate-report",
        data
      );
      return await response.json();
    },
    onSuccess: (data) => {
      form.setValue("content", data.content);
      form.setValue("aiGenerated", true);
      
      toast({
        title: "AI Report Generated",
        description: "The report has been generated based on patient data.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to generate AI report: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Create medical report mutation
  const createReportMutation = useMutation({
    mutationFn: async (data: ReportFormValues) => {
      // Convert form data to the format expected by the API
      const reportData = {
        title: data.title,
        content: data.content,
        date: new Date(data.date),
        aiGenerated: data.aiGenerated,
        patientId,
      };

      const response = await apiRequest(
        "POST",
        `/api/patients/${patientId}/reports`,
        reportData
      );
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Report created",
        description: "The medical report has been successfully created.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patientId, 'reports'] });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create report: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Watch for AI option changes
  const useAI = form.watch("useAI");

  // Handle AI report generation
  const handleGenerateAIReport = () => {
    if (!patient) return;
    
    // Extract medical history as strings
    const medicalHistoryList = medicalHistory 
      ? medicalHistory.map(history => history.title + ": " + history.description)
      : [];
    
    // Get symptoms and vital signs from form
    const currentSymptoms = form.getValues("currentSymptoms") || "";
    const vitalSigns = form.getValues("vitalSigns");
    
    aiReportMutation.mutate({
      patientInfo: {
        name: `${patient.firstName} ${patient.lastName}`,
        age: new Date().getFullYear() - new Date(patient.dateOfBirth).getFullYear(),
        gender: patient.gender,
        medicalHistory: medicalHistoryList,
        currentSymptoms,
        vitalSigns,
      }
    });
  };

  function onSubmit(data: ReportFormValues) {
    createReportMutation.mutate(data);
  }

  const isAiLoading = aiReportMutation.isPending;
  const isSubmitting = createReportMutation.isPending;

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Report Title</FormLabel>
              <FormControl>
                <Input placeholder="Enter report title" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="date"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Report Date</FormLabel>
              <FormControl>
                <Input type="date" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {user?.role === 'doctor' && (
          <FormField
            control={form.control}
            name="useAI"
            render={({ field }) => (
              <FormItem>
                <div className="flex items-center space-x-2">
                  <FormControl>
                    <Checkbox 
                      checked={field.value} 
                      onCheckedChange={field.onChange} 
                    />
                  </FormControl>
                  <FormLabel className="text-sm font-medium">
                    Use AI to generate medical report content
                  </FormLabel>
                </div>
              </FormItem>
            )}
          />
        )}

        {useAI && (
          <Card className="bg-gray-50">
            <CardContent className="p-4 space-y-4">
              <Alert className="bg-blue-50 border-blue-200">
                <Lightbulb className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">AI-Assisted Report Generation</AlertTitle>
                <AlertDescription className="text-blue-700 text-sm">
                  Provide the current symptoms and vital signs to generate a detailed report.
                </AlertDescription>
              </Alert>
              
              <FormField
                control={form.control}
                name="currentSymptoms"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Current Symptoms</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Describe the patient's current symptoms..." 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="vitalSigns.bloodPressure"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Blood Pressure</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 120/80" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="vitalSigns.heartRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Heart Rate (bpm)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="e.g. 72" 
                          {...field}
                          value={field.value || ""}
                          onChange={(e) => {
                            field.onChange(e.target.value ? parseInt(e.target.value) : undefined);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="vitalSigns.temperature"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Temperature (°C)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.1"
                          placeholder="e.g. 37.0" 
                          {...field}
                          value={field.value || ""}
                          onChange={(e) => {
                            field.onChange(e.target.value ? parseFloat(e.target.value) : undefined);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <Button 
                type="button" 
                variant="outline" 
                className="bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100 hover:text-blue-800" 
                onClick={handleGenerateAIReport}
                disabled={isAiLoading}
              >
                {isAiLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Generating Report...
                  </>
                ) : (
                  <>
                    <Lightbulb className="mr-2 h-4 w-4" />
                    Generate AI Report
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        )}

        <FormField
          control={form.control}
          name="content"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Report Content</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Enter the medical report content..." 
                  className="min-h-[300px]"
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="aiGenerated"
          render={({ field }) => (
            <FormItem>
              <div className="flex items-center space-x-2">
                <FormControl>
                  <Checkbox 
                    checked={field.value} 
                    onCheckedChange={field.onChange} 
                    disabled={!useAI}
                  />
                </FormControl>
                <FormLabel className="text-sm font-medium">
                  Mark as AI-generated content
                </FormLabel>
              </div>
              {field.value && (
                <Alert variant="destructive" className="mt-2">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Important</AlertTitle>
                  <AlertDescription>
                    This report will be marked as AI-generated. Always review the content before finalizing.
                  </AlertDescription>
                </Alert>
              )}
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-3 pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            {isSubmitting ? "Saving..." : "Save Report"}
          </Button>
        </div>
      </form>
    </Form>
  );
}

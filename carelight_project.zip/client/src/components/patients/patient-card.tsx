import { Patient } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Pencil, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { nl } from "date-fns/locale";

interface PatientCardProps {
  patient: Patient;
  onEdit: () => void;
}

const PatientCard: React.FC<PatientCardProps> = ({ patient, onEdit }) => {
  return (
    <Card className="bg-white overflow-hidden">
      <div className="p-6 border-b border-neutral-200">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-neutral-800">Patiëntgegevens</h2>
          <Button variant="ghost" size="icon" onClick={onEdit}>
            <Pencil className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <CardContent className="p-6">
        <div className="flex flex-col items-center mb-6">
          <div className="h-24 w-24 rounded-full bg-neutral-200 flex items-center justify-center text-neutral-500 mb-3">
            <User className="h-12 w-12" />
          </div>
          <h3 className="text-xl font-medium text-neutral-800">
            {patient.firstName} {patient.lastName}
          </h3>
          <p className="text-neutral-500">
            RRN: {patient.rijksregisternummer || "Niet geregistreerd"}
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <p className="text-sm text-neutral-500 mb-1">Geboortedatum</p>
            <p className="text-neutral-800">
              {format(new Date(patient.birthDate), 'dd MMMM yyyy', { locale: nl })}
            </p>
          </div>

          <div>
            <p className="text-sm text-neutral-500 mb-1">Geslacht</p>
            <p className="text-neutral-800">{patient.gender}</p>
          </div>

          <div>
            <p className="text-sm text-neutral-500 mb-1">Adres</p>
            <p className="text-neutral-800">
              {patient.address ? `${patient.address}, ${patient.postalCode} ${patient.city}` : "Niet geregistreerd"}
            </p>
          </div>

          <div>
            <p className="text-sm text-neutral-500 mb-1">Telefoonnummer</p>
            <p className="text-neutral-800">
              {patient.phoneNumber || "Niet geregistreerd"}
            </p>
          </div>

          <div>
            <p className="text-sm text-neutral-500 mb-1">E-mail</p>
            <p className="text-neutral-800">{patient.email || "Niet geregistreerd"}</p>
          </div>

          <div>
            <p className="text-sm text-neutral-500 mb-1">Huisarts</p>
            <p className="text-neutral-800">
              {patient.primaryDoctor || "Niet geregistreerd"}
            </p>
          </div>

          <div>
            <p className="text-sm text-neutral-500 mb-1">Bloedgroep</p>
            <p className="text-neutral-800">{patient.bloodType || "Onbekend"}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default PatientCard;

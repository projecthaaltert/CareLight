import { useQuery } from "@tanstack/react-query";
import { Appointment } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { format, compareAsc } from "date-fns";
import { 
  Plus, 
  CalendarClock, 
  Clock, 
  User, 
  MapPin, 
  Video, 
  Edit, 
  X 
} from "lucide-react";

interface UpcomingAppointmentsProps {
  patientId: number;
  onNewAppointment?: () => void;
}

export default function UpcomingAppointments({ patientId, onNewAppointment }: UpcomingAppointmentsProps) {
  const { data: appointments, isLoading } = useQuery<Appointment[]>({
    queryKey: ['/api/patients', patientId, 'appointments'],
    enabled: !!patientId,
  });
  
  // Sort appointments by date and filter for upcoming ones
  const upcomingAppointments = appointments
    ? appointments
        .filter(appointment => compareAsc(new Date(appointment.date), new Date()) >= 0)
        .sort((a, b) => compareAsc(new Date(a.date), new Date(b.date)))
    : [];
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-800';
      case 'scheduled':
        return 'bg-blue-100 text-blue-800';
      case 'tentative':
        return 'bg-gray-100 text-gray-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  return (
    <Card className="h-full">
      <CardHeader className="px-4 py-3 border-b border-gray-100 flex justify-between items-center">
        <CardTitle className="text-base font-medium text-gray-800">Upcoming Appointments</CardTitle>
        <Button 
          variant="default" 
          size="sm" 
          className="flex items-center"
          onClick={onNewAppointment}
        >
          <Plus className="h-4 w-4 mr-1" />
          Schedule
        </Button>
      </CardHeader>
      
      <CardContent className="p-4">
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <Skeleton key={i} className="h-28 w-full" />
            ))}
          </div>
        ) : !upcomingAppointments || upcomingAppointments.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <CalendarClock className="h-12 w-12 mx-auto mb-3 text-gray-300" />
            <p>No upcoming appointments scheduled.</p>
            <Button 
              variant="outline" 
              size="sm" 
              className="mt-4"
              onClick={onNewAppointment}
            >
              <Plus className="h-4 w-4 mr-1" />
              Schedule Appointment
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {upcomingAppointments.map((appointment) => (
              <div key={appointment.id} className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                <div className="flex">
                  <div className="mr-4 flex-none">
                    <div className="text-center bg-white rounded-lg border border-gray-200 p-2 w-14">
                      <div className="text-xs text-gray-600 uppercase font-medium">
                        {format(new Date(appointment.date), "MMM")}
                      </div>
                      <div className="text-2xl font-bold text-gray-800">
                        {format(new Date(appointment.date), "dd")}
                      </div>
                      <div className="text-xs text-gray-600">
                        {format(new Date(appointment.date), "EEE")}
                      </div>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-sm font-medium text-gray-800">{appointment.title}</h3>
                        <p className="text-xs text-gray-500 mt-1">{appointment.description}</p>
                      </div>
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(appointment.status)}`}>
                        {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                      </span>
                    </div>
                    
                    <div className="mt-3 flex flex-wrap items-center text-xs text-gray-500 gap-2">
                      <div className="flex items-center">
                        <Clock className="text-gray-400 h-3 w-3 mr-1" />
                        <span>{appointment.startTime} - {appointment.endTime}</span>
                      </div>
                      <div className="flex items-center">
                        <User className="text-gray-400 h-3 w-3 mr-1" />
                        <span>Dr. {appointment.doctorId}</span>
                      </div>
                      <div className="flex items-center">
                        {appointment.location.toLowerCase().includes('teleconsult') ? (
                          <Video className="text-gray-400 h-3 w-3 mr-1" />
                        ) : (
                          <MapPin className="text-gray-400 h-3 w-3 mr-1" />
                        )}
                        <span>{appointment.location}</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Only show action buttons for non-past appointments */}
                {appointment.status !== 'completed' && (
                  <div className="mt-4 flex justify-end space-x-2">
                    <Button variant="ghost" size="sm" className="text-gray-600 h-8">
                      <Edit className="h-3 w-3 mr-1" />
                      Reschedule
                    </Button>
                    <Button variant="ghost" size="sm" className="text-red-500 h-8">
                      <X className="h-3 w-3 mr-1" />
                      Cancel
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { HealthMetric } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { format, subMonths } from "date-fns";
import {
  ChartBarStacked as BarChartIcon,
  TrendingDown,
  TrendingUp,
  Minus,
  Activity,
  Droplet,
  Weight
} from "lucide-react";

interface HealthTrendsProps {
  patientId: number;
}

type Period = '3m' | '6m' | '1y';

export default function HealthTrends({ patientId }: HealthTrendsProps) {
  const [period, setPeriod] = useState<Period>('3m');
  
  const { data: bloodPressureMetrics, isLoading: isLoadingBP } = useQuery<HealthMetric[]>({
    queryKey: ['/api/patients', patientId, 'health-metrics', 'blood pressure'],
    enabled: !!patientId,
  });
  
  const { data: glucoseMetrics, isLoading: isLoadingGlucose } = useQuery<HealthMetric[]>({
    queryKey: ['/api/patients', patientId, 'health-metrics', 'glucose'],
    enabled: !!patientId,
  });
  
  const { data: weightMetrics, isLoading: isLoadingWeight } = useQuery<HealthMetric[]>({
    queryKey: ['/api/patients', patientId, 'health-metrics', 'weight'],
    enabled: !!patientId,
  });
  
  const isLoading = isLoadingBP || isLoadingGlucose || isLoadingWeight;
  
  // Filter metrics by selected period
  const filterByPeriod = (metrics: HealthMetric[] | undefined) => {
    if (!metrics) return [];
    
    const cutoffDate = subMonths(
      new Date(),
      period === '3m' ? 3 : period === '6m' ? 6 : 12
    );
    
    return metrics
      .filter(metric => new Date(metric.date) >= cutoffDate)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  };
  
  // Prepare chart data
  const prepareChartData = () => {
    const bpData = filterByPeriod(bloodPressureMetrics);
    const glucoseData = filterByPeriod(glucoseMetrics);
    const weightData = filterByPeriod(weightMetrics);
    
    // Combine the data for the chart
    const chartData = [];
    
    // Use the dates from blood pressure metrics as the base
    for (const metric of bpData) {
      const date = new Date(metric.date);
      const formattedDate = format(date, 'MMM dd');
      
      // Parse blood pressure (e.g., "120/80") to get systolic and diastolic
      const [systolic, diastolic] = metric.value.split('/').map(v => parseInt(v.trim()));
      
      // Find glucose reading for this date if it exists
      const glucoseReading = glucoseData.find(
        g => format(new Date(g.date), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
      );
      
      // Find weight reading for this date if it exists
      const weightReading = weightData.find(
        w => format(new Date(w.date), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
      );
      
      chartData.push({
        date: formattedDate,
        systolic,
        diastolic,
        glucose: glucoseReading ? parseFloat(glucoseReading.value) : null,
        weight: weightReading ? parseFloat(weightReading.value) : null,
      });
    }
    
    return chartData;
  };
  
  const chartData = prepareChartData();
  
  // Calculate trends
  const calculateTrend = (metrics: HealthMetric[] | undefined) => {
    if (!metrics || metrics.length < 2) return 0;
    
    const sortedMetrics = [...metrics].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );
    
    const firstValue = parseFloat(sortedMetrics[0].value.split('/')[0] || sortedMetrics[0].value);
    const lastValue = parseFloat(sortedMetrics[sortedMetrics.length - 1].value.split('/')[0] || sortedMetrics[sortedMetrics.length - 1].value);
    
    return ((lastValue - firstValue) / firstValue) * 100;
  };
  
  const bpTrend = calculateTrend(bloodPressureMetrics);
  const glucoseTrend = calculateTrend(glucoseMetrics);
  const weightTrend = calculateTrend(weightMetrics);
  
  const getTrendIcon = (trend: number) => {
    if (trend < -1) return <TrendingDown className="text-green-500 h-3 w-3 mr-1" />;
    if (trend > 1) return <TrendingUp className="text-red-500 h-3 w-3 mr-1" />;
    return <Minus className="text-yellow-500 h-3 w-3 mr-1" />;
  };
  
  return (
    <Card className="bg-white">
      <CardHeader className="px-4 py-3 border-b border-gray-100 flex justify-between items-center">
        <CardTitle className="text-base font-medium text-gray-800">Health Trends</CardTitle>
        <div className="flex space-x-2">
          <Button 
            variant={period === '3m' ? "default" : "outline"} 
            size="sm" 
            onClick={() => setPeriod('3m')}
            className="text-xs h-8"
          >
            Last 3 Months
          </Button>
          <Button 
            variant={period === '6m' ? "default" : "outline"} 
            size="sm" 
            onClick={() => setPeriod('6m')}
            className="text-xs h-8"
          >
            Last 6 Months
          </Button>
          <Button 
            variant={period === '1y' ? "default" : "outline"} 
            size="sm" 
            onClick={() => setPeriod('1y')}
            className="text-xs h-8"
          >
            1 Year
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="p-4">
        {isLoading ? (
          <div>
            <Skeleton className="h-64 w-full mb-4" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[...Array(3)].map((_, i) => (
                <Skeleton key={i} className="h-24 w-full" />
              ))}
            </div>
          </div>
        ) : chartData.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <BarChartIcon className="h-12 w-12 mx-auto mb-3 text-gray-300" />
            <p>No health metrics available for the selected period.</p>
          </div>
        ) : (
          <>
            {/* Chart */}
            <div className="h-64 bg-gray-50 rounded-lg border border-gray-200 p-4">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={chartData}
                  margin={{ top: 5, right: 30, left: 10, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis yAxisId="pressure" />
                  <YAxis yAxisId="glucose" orientation="right" />
                  <Tooltip />
                  <Legend />
                  <Line 
                    yAxisId="pressure"
                    type="monotone" 
                    dataKey="systolic" 
                    stroke="#1A6AA5" 
                    name="Systolic" 
                    strokeWidth={2}
                    dot={{ r: 3 }}
                  />
                  <Line 
                    yAxisId="pressure"
                    type="monotone" 
                    dataKey="diastolic" 
                    stroke="#46A9C8" 
                    name="Diastolic" 
                    strokeWidth={2}
                    dot={{ r: 3 }}
                  />
                  <Line 
                    yAxisId="glucose"
                    type="monotone" 
                    dataKey="glucose" 
                    stroke="#F9943B" 
                    name="Glucose" 
                    strokeWidth={2}
                    dot={{ r: 3 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            
            {/* Key indicators */}
            <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gray-50 rounded-lg p-3 border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs font-medium text-gray-500">Blood Pressure</div>
                    <div className="text-xl font-semibold mt-1">
                      {bloodPressureMetrics && bloodPressureMetrics.length > 0 
                        ? bloodPressureMetrics[bloodPressureMetrics.length - 1].value 
                        : "N/A"}
                      <span className="text-sm font-normal text-gray-500"> mmHg</span>
                    </div>
                  </div>
                  <div className="rounded-full bg-green-100 p-2">
                    <Activity className="text-green-600 h-5 w-5" />
                  </div>
                </div>
                <div className="mt-2 text-xs text-gray-500 flex items-center">
                  {getTrendIcon(bpTrend)}
                  <span>
                    {Math.abs(bpTrend) < 1 
                      ? "Stable within normal range" 
                      : `${Math.abs(bpTrend).toFixed(1)}% ${bpTrend < 0 ? "lower" : "higher"} than previous`}
                  </span>
                </div>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-3 border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs font-medium text-gray-500">Glucose Level</div>
                    <div className="text-xl font-semibold mt-1">
                      {glucoseMetrics && glucoseMetrics.length > 0 
                        ? glucoseMetrics[glucoseMetrics.length - 1].value 
                        : "N/A"}
                      <span className="text-sm font-normal text-gray-500"> mmol/L</span>
                    </div>
                  </div>
                  <div className="rounded-full bg-yellow-100 p-2">
                    <Droplet className="text-yellow-600 h-5 w-5" />
                  </div>
                </div>
                <div className="mt-2 text-xs text-gray-500 flex items-center">
                  {getTrendIcon(glucoseTrend)}
                  <span>
                    {Math.abs(glucoseTrend) < 1 
                      ? "Stable within normal range" 
                      : `${Math.abs(glucoseTrend).toFixed(1)}% ${glucoseTrend < 0 ? "lower" : "higher"} than previous`}
                  </span>
                </div>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-3 border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs font-medium text-gray-500">Body Weight</div>
                    <div className="text-xl font-semibold mt-1">
                      {weightMetrics && weightMetrics.length > 0 
                        ? weightMetrics[weightMetrics.length - 1].value 
                        : "N/A"}
                      <span className="text-sm font-normal text-gray-500"> kg</span>
                    </div>
                  </div>
                  <div className="rounded-full bg-blue-100 p-2">
                    <Weight className="text-blue-600 h-5 w-5" />
                  </div>
                </div>
                <div className="mt-2 text-xs text-gray-500 flex items-center">
                  {getTrendIcon(weightTrend)}
                  <span>
                    {Math.abs(weightTrend) < 1 
                      ? "Stable" 
                      : `${Math.abs(weightTrend).toFixed(1)}% ${weightTrend < 0 ? "less" : "more"} than ${period === '3m' ? '3 months' : period === '6m' ? '6 months' : 'a year'} ago`}
                  </span>
                </div>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

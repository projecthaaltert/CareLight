import { useQuery } from "@tanstack/react-query";
import { Prescription } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { usePdf } from "@/hooks/use-pdf";
import { format } from "date-fns";
import { useAuth } from "@/hooks/use-auth";
import { 
  Plus, 
  FileText, 
  Download, 
  Edit, 
  RefreshCw, 
  Pill 
} from "lucide-react";

interface ActivePrescriptionsProps {
  patientId: number;
  onNewPrescription?: () => void;
}

export default function ActivePrescriptions({ patientId, onNewPrescription }: ActivePrescriptionsProps) {
  const { user } = useAuth();
  const { fetchAndDownloadPdf } = usePdf();
  
  const { data: prescriptions, isLoading } = useQuery<Prescription[]>({
    queryKey: ['/api/patients', patientId, 'prescriptions'],
    enabled: !!patientId,
  });
  
  const handleDownloadPdf = (prescriptionId: number) => {
    fetchAndDownloadPdf(
      `/api/prescriptions/${prescriptionId}/pdf`,
      `prescription_${prescriptionId}.pdf`
    );
  };
  
  const isDoctor = user?.role === 'doctor';
  
  return (
    <Card className="h-full">
      <CardHeader className="px-4 py-3 border-b border-gray-100 flex justify-between items-center">
        <CardTitle className="text-base font-medium text-gray-800">Active Prescriptions</CardTitle>
        {isDoctor && (
          <Button 
            variant="default" 
            size="sm" 
            className="flex items-center" 
            onClick={onNewPrescription}
          >
            <Plus className="h-4 w-4 mr-1" />
            New Prescription
          </Button>
        )}
      </CardHeader>
      
      <CardContent className="p-4">
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(2)].map((_, i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </div>
        ) : !prescriptions || prescriptions.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <FileText className="h-12 w-12 mx-auto mb-3 text-gray-300" />
            <p>No active prescriptions found.</p>
            {isDoctor && (
              <Button 
                variant="outline" 
                size="sm" 
                className="mt-4"
                onClick={onNewPrescription}
              >
                <Plus className="h-4 w-4 mr-1" />
                Create Prescription
              </Button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr>
                  <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Medication
                  </th>
                  <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Dosage
                  </th>
                  <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Frequency
                  </th>
                  <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    End Date
                  </th>
                  <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {prescriptions.map((prescription) => (
                  <tr key={prescription.id}>
                    <td className="px-3 py-3 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-8 w-8 flex-shrink-0 bg-blue-100 rounded-full flex items-center justify-center">
                          <Pill className="text-primary-500 h-4 w-4" />
                        </div>
                        <div className="ml-3">
                          <div className="text-sm font-medium text-gray-900">{prescription.medication}</div>
                          <div className="text-xs text-gray-500">
                            {prescription.instructions?.slice(0, 20) || 'No instructions'}
                            {prescription.instructions && prescription.instructions.length > 20 ? '...' : ''}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      <div className="text-sm text-gray-900 font-mono">{prescription.dosage}</div>
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{prescription.frequency}</div>
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {prescription.endDate 
                          ? format(new Date(prescription.endDate), "dd MMM yyyy")
                          : 'Ongoing'}
                      </div>
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap text-sm font-medium">
                      <div className="flex space-x-2">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-8 w-8 p-0" 
                          onClick={() => handleDownloadPdf(prescription.id)}
                          title="Download PDF"
                        >
                          <Download className="h-4 w-4 text-primary-500" />
                        </Button>
                        {isDoctor && (
                          <>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-8 w-8 p-0" 
                              title="Edit"
                            >
                              <Edit className="h-4 w-4 text-gray-500" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-8 w-8 p-0" 
                              title="Renew"
                            >
                              <RefreshCw className="h-4 w-4 text-gray-500" />
                            </Button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Patient } from "@shared/schema";
import { Loader2 } from "lucide-react";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import PatientView from "@/components/patients/patient-view";
import { useMediaQuery } from "@/hooks/use-mobile";

const PatientPage = () => {
  const { id } = useParams<{ id: string }>();
  const patientId = parseInt(id);
  const isMobile = useMediaQuery("(max-width: 768px)");

  const { data: patient, isLoading, error } = useQuery<Patient>({
    queryKey: [`/api/patients/${patientId}`],
  });

  if (isLoading) {
    return (
      <div className="flex flex-col h-screen">
        <Header />
        <div className="flex flex-1 overflow-hidden">
          <Sidebar isMobile={isMobile} />
          <main className="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6">
            <div className="h-full flex items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          </main>
        </div>
      </div>
    );
  }

  if (error || !patient) {
    return (
      <div className="flex flex-col h-screen">
        <Header />
        <div className="flex flex-1 overflow-hidden">
          <Sidebar isMobile={isMobile} />
          <main className="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6">
            <div className="h-full flex items-center justify-center">
              <div className="text-center">
                <h3 className="text-lg font-medium text-neutral-800 mb-2">
                  Patiënt niet gevonden
                </h3>
                <p className="text-neutral-600">
                  De opgevraagde patiënt kon niet worden gevonden.
                </p>
              </div>
            </div>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar isMobile={isMobile} />
        <main className="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6">
          <PatientView patientId={patientId} />
        </main>
      </div>
    </div>
  );
};

export default PatientPage;

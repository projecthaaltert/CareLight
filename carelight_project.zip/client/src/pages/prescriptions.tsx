import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Layout from "@/components/layout/layout";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Prescription, Patient } from "@shared/schema";
import { usePdf } from "@/hooks/use-pdf";
import PrescriptionModal from "@/components/prescriptions/prescription-modal";
import { format } from "date-fns";
import {
  Plus,
  Search,
  Download,
  Edit,
  RefreshCw,
  Pill,
  User,
  FileTextIcon,
  Calendar,
  Loader2
} from "lucide-react";

export default function Prescriptions() {
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedPatientId, setSelectedPatientId] = useState<number | null>(null);
  const [showPrescriptionModal, setShowPrescriptionModal] = useState(false);
  const { fetchAndDownloadPdf } = usePdf();
  
  // Get all prescriptions
  const { data: prescriptions, isLoading: isLoadingPrescriptions } = useQuery<Prescription[]>({
    queryKey: ["/api/prescriptions"],
  });
  
  // Get all patients for the dropdown
  const { data: patients, isLoading: isLoadingPatients } = useQuery<Patient[]>({
    queryKey: ["/api/patients"],
  });
  
  // Filter prescriptions based on search, status, and patient
  const filteredPrescriptions = prescriptions?.filter(prescription => {
    let matchesSearch = true;
    let matchesStatus = true;
    let matchesPatient = true;
    
    // Search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      matchesSearch = prescription.medication.toLowerCase().includes(query);
    }
    
    // Status filter
    if (statusFilter !== "all") {
      matchesStatus = prescription.status === statusFilter;
    }
    
    // Patient filter
    if (selectedPatientId !== null) {
      matchesPatient = prescription.patientId === selectedPatientId;
    }
    
    return matchesSearch && matchesStatus && matchesPatient;
  });
  
  const handleDownloadPdf = (prescriptionId: number) => {
    fetchAndDownloadPdf(
      `/api/prescriptions/${prescriptionId}/pdf`,
      `prescription_${prescriptionId}.pdf`
    );
  };
  
  const openNewPrescriptionModal = (patientId?: number) => {
    if (patientId) {
      setSelectedPatientId(patientId);
    }
    setShowPrescriptionModal(true);
  };
  
  const findPatientName = (patientId: number) => {
    const patient = patients?.find(p => p.id === patientId);
    return patient ? `${patient.firstName} ${patient.lastName}` : `Patient #${patientId}`;
  };
  
  const isLoading = isLoadingPrescriptions || isLoadingPatients;
  
  return (
    <Layout>
      <div className="p-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
          <div>
            <h1 className="text-2xl font-semibold text-gray-800">Prescriptions</h1>
            <p className="text-sm text-gray-500">
              Manage and create patient prescriptions
            </p>
          </div>
          
          <div className="mt-4 md:mt-0">
            <Button onClick={() => openNewPrescriptionModal()}>
              <Plus className="h-4 w-4 mr-2" />
              New Prescription
            </Button>
          </div>
        </div>
        
        <div className="bg-white rounded-lg border border-gray-200 mb-6">
          <div className="p-4 border-b border-gray-200">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  placeholder="Search prescriptions..."
                  className="pl-9"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              
              <div className="flex gap-4">
                <div className="w-48">
                  <Select
                    value={statusFilter}
                    onValueChange={setStatusFilter}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="w-64">
                  <Select
                    value={selectedPatientId?.toString() || ""}
                    onValueChange={(value) => setSelectedPatientId(value ? parseInt(value) : null)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="All Patients" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All Patients</SelectItem>
                      {patients?.map((patient) => (
                        <SelectItem key={patient.id} value={patient.id.toString()}>
                          {patient.firstName} {patient.lastName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>
          
          <div className="p-4">
            <Tabs defaultValue="active">
              <TabsList>
                <TabsTrigger value="active" onClick={() => setStatusFilter("active")}>
                  Active
                </TabsTrigger>
                <TabsTrigger value="all" onClick={() => setStatusFilter("all")}>
                  All Prescriptions
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          
          {isLoading ? (
            <div className="text-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary-500 mx-auto" />
              <p className="mt-2 text-gray-500">Loading prescriptions...</p>
            </div>
          ) : filteredPrescriptions?.length === 0 ? (
            <div className="text-center py-12">
              <FileTextIcon className="h-12 w-12 text-gray-300 mx-auto mb-3" />
              <h3 className="text-lg font-medium text-gray-900">No prescriptions found</h3>
              <p className="text-gray-500 mt-1">
                {searchQuery || statusFilter !== "all" || selectedPatientId 
                  ? "No prescriptions match your filter criteria." 
                  : "You haven't created any prescriptions yet."}
              </p>
              <Button className="mt-4" onClick={() => openNewPrescriptionModal()}>
                <Plus className="h-4 w-4 mr-2" />
                Create Prescription
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead>Patient</TableHead>
                    <TableHead>Medication</TableHead>
                    <TableHead>Dosage</TableHead>
                    <TableHead>Frequency</TableHead>
                    <TableHead>Date Range</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPrescriptions?.map((prescription) => (
                    <TableRow key={prescription.id} className="hover:bg-gray-50">
                      <TableCell>
                        <div className="flex items-center">
                          <User className="h-8 w-8 text-gray-400 bg-gray-100 p-1.5 rounded-full mr-2" />
                          <div>
                            <p>{findPatientName(prescription.patientId)}</p>
                            <p className="text-xs text-gray-500">
                              ID: {prescription.patientId}
                            </p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Pill className="h-8 w-8 flex-shrink-0 bg-blue-100 rounded-full p-2 text-primary-500 mr-2" />
                          <div>
                            <p className="font-medium">{prescription.medication}</p>
                            <p className="text-xs text-gray-500">
                              {prescription.instructions?.slice(0, 30)}
                              {prescription.instructions && prescription.instructions.length > 30 ? '...' : ''}
                            </p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="font-mono">{prescription.dosage}</TableCell>
                      <TableCell>{prescription.frequency}</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1 text-gray-400" />
                          <div>
                            <p>{format(new Date(prescription.startDate), "MMM d, yyyy")}</p>
                            {prescription.endDate && (
                              <p className="text-xs text-gray-500">
                                to {format(new Date(prescription.endDate), "MMM d, yyyy")}
                              </p>
                            )}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          prescription.status === 'active' 
                            ? 'bg-green-100 text-green-800' 
                            : prescription.status === 'completed' 
                            ? 'bg-gray-100 text-gray-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {prescription.status.charAt(0).toUpperCase() + prescription.status.slice(1)}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0" 
                            onClick={() => handleDownloadPdf(prescription.id)}
                            title="Download PDF"
                          >
                            <Download className="h-4 w-4 text-primary-500" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0" 
                            title="Edit"
                          >
                            <Edit className="h-4 w-4 text-gray-500" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0" 
                            title="Renew"
                          >
                            <RefreshCw className="h-4 w-4 text-gray-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
      </div>
      
      {showPrescriptionModal && (
        <PrescriptionModal 
          patientId={selectedPatientId || 0}
          isOpen={showPrescriptionModal}
          onClose={() => {
            setShowPrescriptionModal(false);
            if (!patients?.find(p => p.id === selectedPatientId)) {
              setSelectedPatientId(null);
            }
          }}
        />
      )}
    </Layout>
  );
}

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation, useParams } from "wouter";
import Layout from "@/components/layout/layout";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PatientInfoPanel from "@/components/patients/patient-info-panel";
import MedicalHistoryTimeline from "@/components/medical/medical-history-timeline";
import ActivePrescriptions from "@/components/medical/active-prescriptions";
import UpcomingAppointments from "@/components/medical/upcoming-appointments";
import HealthTrends from "@/components/medical/health-trends";
import PrescriptionModal from "@/components/prescriptions/prescription-modal";
import { Patient } from "@shared/schema";
import { ChevronLeft, Loader2 } from "lucide-react";

export default function PatientDetails() {
  const params = useParams();
  const patientId = parseInt(params.id);
  const [, navigate] = useLocation();
  const [showPrescriptionModal, setShowPrescriptionModal] = useState(false);
  
  const { data: patient, isLoading, error } = useQuery<Patient>({
    queryKey: ['/api/patients', patientId],
    enabled: !isNaN(patientId),
  });
  
  if (isNaN(patientId)) {
    return (
      <Layout>
        <div className="p-6">
          <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
            <h3 className="text-lg font-medium text-red-700">Invalid Patient ID</h3>
            <p className="text-gray-500 mt-2">The patient ID is not valid.</p>
            <Button className="mt-4" onClick={() => navigate("/patients")}>
              <ChevronLeft className="h-4 w-4 mr-2" />
              Back to Patients
            </Button>
          </div>
        </div>
      </Layout>
    );
  }
  
  if (isLoading) {
    return (
      <Layout>
        <div className="flex justify-center items-center min-h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-primary-500" />
        </div>
      </Layout>
    );
  }
  
  if (error || !patient) {
    return (
      <Layout>
        <div className="p-6">
          <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
            <h3 className="text-lg font-medium text-red-700">Patient Not Found</h3>
            <p className="text-gray-500 mt-2">The requested patient could not be found.</p>
            <Button className="mt-4" onClick={() => navigate("/patients")}>
              <ChevronLeft className="h-4 w-4 mr-2" />
              Back to Patients
            </Button>
          </div>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout>
      <div className="p-6">
        <div className="mb-6">
          <Button 
            variant="ghost" 
            size="sm" 
            className="mb-2"
            onClick={() => navigate("/patients")}
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Back to Patients
          </Button>
          <h1 className="text-2xl font-semibold text-gray-800">Patient Overview</h1>
        </div>
        
        <PatientInfoPanel patient={patient} />
        
        <Tabs defaultValue="overview" className="mb-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="medical-history">Medical History</TabsTrigger>
            <TabsTrigger value="prescriptions">Prescriptions</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
            <TabsTrigger value="lab-results">Lab Results</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview">
            <div>
              <MedicalHistoryTimeline patientId={patientId} />
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                <ActivePrescriptions 
                  patientId={patientId} 
                  onNewPrescription={() => setShowPrescriptionModal(true)} 
                />
                <UpcomingAppointments patientId={patientId} />
              </div>
              
              <HealthTrends patientId={patientId} />
            </div>
          </TabsContent>
          
          <TabsContent value="medical-history">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h2 className="text-xl font-semibold mb-4">Medical History</h2>
              <div className="mb-4">
                <Button variant="outline">Add Medical History Entry</Button>
              </div>
              <MedicalHistoryTimeline patientId={patientId} />
            </div>
          </TabsContent>
          
          <TabsContent value="prescriptions">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">Prescriptions</h2>
                <Button onClick={() => setShowPrescriptionModal(true)}>
                  New Prescription
                </Button>
              </div>
              <ActivePrescriptions 
                patientId={patientId} 
                onNewPrescription={() => setShowPrescriptionModal(true)} 
              />
            </div>
          </TabsContent>
          
          <TabsContent value="reports">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">Medical Reports</h2>
                <Button onClick={() => navigate(`/patients/${patientId}/reports/new`)}>
                  New Report
                </Button>
              </div>
              <p className="text-gray-500">Medical reports will be displayed here.</p>
            </div>
          </TabsContent>
          
          <TabsContent value="lab-results">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h2 className="text-xl font-semibold mb-4">Lab Results</h2>
              <p className="text-gray-500">Lab results will be displayed here.</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
      
      <PrescriptionModal 
        patientId={patientId}
        isOpen={showPrescriptionModal}
        onClose={() => setShowPrescriptionModal(false)}
      />
    </Layout>
  );
}

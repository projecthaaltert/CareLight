import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertUserSchema } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2 } from "lucide-react";

// Login schema
const loginSchema = z.object({
  username: z.string().min(1, "Gebruikersnaam is verplicht"),
  password: z.string().min(1, "Wachtwoord is verplicht"),
});

type LoginValues = z.infer<typeof loginSchema>;

// Registration schema
const registerSchema = insertUserSchema.pick({
  username: true,
  password: true,
  fullName: true,
  email: true,
  role: true,
  specialty: true,
  registrationNumber: true,
}).extend({
  confirmPassword: z.string().min(1, "Bevestig wachtwoord is verplicht"),
}).refine(
  (data) => data.password === data.confirmPassword,
  {
    message: "Wachtwoorden komen niet overeen",
    path: ["confirmPassword"],
  }
);

type RegisterValues = z.infer<typeof registerSchema>;

const AuthPage = () => {
  // Registratie is uitgeschakeld - alleen inloggen is beschikbaar
  const { user, loginMutation, registerMutation } = useAuth();
  const [, setLocation] = useLocation();

  // Redirect if user is already logged in
  useEffect(() => {
    if (user) {
      setLocation("/");
    }
  }, [user, setLocation]);

  // Login form
  const loginForm = useForm<LoginValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  // Register form
  const registerForm = useForm<RegisterValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      fullName: "",
      email: "",
      role: "doctor",
      specialty: "",
      registrationNumber: "",
    },
  });

  const onLoginSubmit = (data: LoginValues) => {
    loginMutation.mutate(data);
  };

  const onRegisterSubmit = (data: RegisterValues) => {
    // Remove confirmPassword field
    const { confirmPassword, ...registerData } = data;
    registerMutation.mutate(registerData);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md mb-6">
        <h1 className="text-center text-3xl font-bold text-primary">
          <span>Care</span><span className="text-success">light</span>
        </h1>
        <h2 className="mt-2 text-center text-xl text-neutral-600">
          Medisch Dossierbeheer Systeem
        </h2>
      </div>

      <div className="sm:mx-auto sm:w-full sm:max-w-6xl px-4">
        <div className="bg-white shadow-md rounded-lg overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2">
            {/* Form Section */}
            <div className="p-6 md:p-8">
              <Card className="border-0 shadow-none">
                <CardHeader>
                  <CardTitle>Inloggen</CardTitle>
                  <CardDescription>
                    Vul uw gebruikersnaam en wachtwoord in om toegang te krijgen tot uw account.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...loginForm}>
                    <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                      <FormField
                        control={loginForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Gebruikersnaam</FormLabel>
                            <FormControl>
                              <Input placeholder="Uw gebruikersnaam" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={loginForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Wachtwoord</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="Uw wachtwoord" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button 
                        type="submit" 
                        className="w-full mt-4"
                        disabled={loginMutation.isPending}
                      >
                        {loginMutation.isPending && (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        )}
                        Inloggen
                      </Button>
                    </form>
                  </Form>
                </CardContent>
                <CardFooter className="flex justify-center">
                  <p className="text-sm text-muted-foreground">
                    Nieuwe gebruikers kunnen worden aangemaakt door een beheerder via het admin paneel.
                  </p>
                </CardFooter>
              </Card>
            </div>
            
            {/* Hero Section */}
            <div className="bg-primary p-8 text-white flex flex-col justify-center">
              <div>
                <h3 className="text-2xl font-bold mb-4">Welkom bij Carelight</h3>
                <p className="mb-6">
                  Het complete medische dossierbeheer systeem voor zorgverleners. Beheer patiëntendossiers, 
                  genereer voorschriften en medische verslagen, en deel veilig patiëntinformatie.
                </p>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="bg-white bg-opacity-20 p-2 rounded-full mr-3">
                      <span className="material-icons">person</span>
                    </div>
                    <div>
                      <h4 className="font-semibold">Patiëntenbeheer</h4>
                      <p className="text-sm opacity-90">
                        Eenvoudig beheer van patiëntgegevens, medische geschiedenis en medicatie.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="bg-white bg-opacity-20 p-2 rounded-full mr-3">
                      <span className="material-icons">description</span>
                    </div>
                    <div>
                      <h4 className="font-semibold">Voorschriften & Verslagen</h4>
                      <p className="text-sm opacity-90">
                        Genereer professionele voorschriften en medische verslagen met één klik.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="bg-white bg-opacity-20 p-2 rounded-full mr-3">
                      <span className="material-icons">security</span>
                    </div>
                    <div>
                      <h4 className="font-semibold">Privacy & Veiligheid</h4>
                      <p className="text-sm opacity-90">
                        Volledig GDPR-compliant met uitgebreide beveiliging van patiëntgegevens.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;

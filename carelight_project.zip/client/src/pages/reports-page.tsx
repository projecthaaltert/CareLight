import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Report, Patient, Consultation } from "@shared/schema";
import { Loader2, Plus, Search, FileText, Download, Printer } from "lucide-react";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import { useMediaQuery } from "@/hooks/use-mobile";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import ReportForm from "@/components/reports/report-form";
import ReportPreview from "@/components/reports/report-preview";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const ReportsPage = () => {
  const isMobile = useMediaQuery("(max-width: 768px)");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPatient, setSelectedPatient] = useState<string>("");
  const [showNewReportModal, setShowNewReportModal] = useState(false);
  const [showReportPreviewModal, setShowReportPreviewModal] = useState(false);
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [selectedPatientForReport, setSelectedPatientForReport] = useState<number | null>(null);

  const { data: reports, isLoading: isLoadingReports } = useQuery<Report[]>({
    queryKey: ['/api/reports'],
  });

  const { data: patients, isLoading: isLoadingPatients } = useQuery<Patient[]>({
    queryKey: ['/api/patients'],
  });

  const isLoading = isLoadingReports || isLoadingPatients;

  const handleViewReport = (report: Report) => {
    setSelectedReport(report);
    setShowReportPreviewModal(true);
  };

  const handleNewReport = (patientId: number) => {
    setSelectedPatientForReport(patientId);
    setShowNewReportModal(true);
  };

  const getPatient = (patientId: number) => {
    return patients?.find(p => p.id === patientId);
  };

  const filteredReports = reports?.filter(report => {
    let matches = true;
    
    // Filter by search query
    if (searchQuery) {
      const patient = getPatient(report.patientId);
      const patientName = patient ? `${patient.firstName} ${patient.lastName}` : "";
      const searchLower = searchQuery.toLowerCase();
      
      matches = matches && (
        report.title.toLowerCase().includes(searchLower) ||
        patientName.toLowerCase().includes(searchLower) ||
        report.content.toLowerCase().includes(searchLower)
      );
    }
    
    // Filter by selected patient
    if (selectedPatient) {
      matches = matches && report.patientId === parseInt(selectedPatient);
    }
    
    return matches;
  }) || [];

  return (
    <div className="flex flex-col h-screen">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar isMobile={isMobile} />
        <main className="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-semibold text-neutral-800">Medische Verslagen</h1>
              <p className="text-neutral-600">Beheer en genereer medische verslagen voor patiënten</p>
            </div>

            <div className="mt-4 md:mt-0 flex flex-col sm:flex-row gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" />
                <Input
                  placeholder="Zoek verslagen..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              {patients && patients.length > 0 && (
                <Select
                  value={selectedPatient}
                  onValueChange={setSelectedPatient}
                >
                  <SelectTrigger className="w-full sm:w-[200px]">
                    <SelectValue placeholder="Alle patiënten" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Alle patiënten</SelectItem>
                    {patients.map((patient) => (
                      <SelectItem 
                        key={patient.id} 
                        value={patient.id.toString()}
                      >
                        {patient.firstName} {patient.lastName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          </div>

          {isLoading ? (
            <div className="h-64 flex items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <>
              {filteredReports.length === 0 ? (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-10">
                    <FileText className="h-10 w-10 text-neutral-300 mb-3" />
                    <p className="text-center text-neutral-600">
                      {searchQuery || selectedPatient ? "Geen verslagen gevonden voor uw zoekopdracht." : "Geen verslagen gevonden. Maak een nieuw verslag aan via een patiëntdossier."}
                    </p>
                    {(searchQuery || selectedPatient) && (
                      <Button variant="outline" className="mt-4" onClick={() => {
                        setSearchQuery("");
                        setSelectedPatient("");
                      }}>
                        Wis zoekopdracht
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-6">
                  {patients?.map(patient => {
                    const patientReports = filteredReports.filter(r => r.patientId === patient.id);
                    if (patientReports.length === 0) return null;
                    
                    return (
                      <Card key={patient.id}>
                        <CardHeader className="flex flex-row items-center justify-between pb-2">
                          <div>
                            <CardTitle className="text-lg font-semibold">
                              {patient.firstName} {patient.lastName}
                            </CardTitle>
                            <p className="text-sm text-neutral-500">
                              {format(new Date(patient.birthDate), 'dd MMMM yyyy', { locale: nl })}
                            </p>
                          </div>
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="flex items-center"
                            onClick={() => handleNewReport(patient.id)}
                          >
                            <Plus className="h-4 w-4 mr-1" />
                            Nieuw verslag
                          </Button>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            {patientReports
                              .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                              .map((report) => (
                                <div 
                                  key={report.id}
                                  className="border border-neutral-200 rounded-md p-4 hover:bg-neutral-50 transition-colors"
                                >
                                  <div className="flex flex-col md:flex-row md:items-center justify-between">
                                    <div>
                                      <div className="flex items-center">
                                        <h4 className="font-medium text-neutral-800">
                                          {report.title}
                                        </h4>
                                        {report.aiGenerated && (
                                          <Badge 
                                            variant="secondary"
                                            className="ml-2"
                                          >
                                            AI gegenereerd
                                          </Badge>
                                        )}
                                      </div>
                                      <p className="text-sm text-neutral-600 mt-1">
                                        Aangemaakt op: {format(new Date(report.date), 'dd-MM-yyyy')}
                                      </p>
                                    </div>
                                    <div className="flex items-center mt-3 md:mt-0">
                                      <Button 
                                        variant="outline" 
                                        size="sm"
                                        className="flex items-center mr-2"
                                        onClick={() => handleViewReport(report)}
                                      >
                                        <Printer className="h-4 w-4 mr-1" />
                                        Afdrukken
                                      </Button>
                                      {report.pdfUrl && (
                                        <Button 
                                          variant="outline" 
                                          size="sm"
                                          className="flex items-center"
                                          asChild
                                        >
                                          <a 
                                            href={report.pdfUrl} 
                                            target="_blank" 
                                            rel="noopener noreferrer"
                                          >
                                            <Download className="h-4 w-4 mr-1" />
                                            PDF
                                          </a>
                                        </Button>
                                      )}
                                    </div>
                                  </div>
                                  
                                  <div className="mt-3">
                                    <p className="text-sm text-neutral-700 line-clamp-2">
                                      {report.content}
                                    </p>
                                  </div>
                                </div>
                              ))}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {/* New Report Modal */}
          {selectedPatientForReport !== null && (
            <Dialog open={showNewReportModal} onOpenChange={setShowNewReportModal}>
              <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Nieuw medisch verslag</DialogTitle>
                </DialogHeader>
                <ReportForm 
                  patientId={selectedPatientForReport}
                  onSuccess={(report) => {
                    setShowNewReportModal(false);
                    setSelectedReport(report);
                    setShowReportPreviewModal(true);
                  }}
                  onCancel={() => setShowNewReportModal(false)}
                />
              </DialogContent>
            </Dialog>
          )}
          
          {/* Report Preview Modal */}
          {selectedReport && getPatient(selectedReport.patientId) && (
            <Dialog open={showReportPreviewModal} onOpenChange={setShowReportPreviewModal}>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Verslag Voorbeeld</DialogTitle>
                </DialogHeader>
                <ReportPreview 
                  report={selectedReport}
                  patient={getPatient(selectedReport.patientId)!}
                  onClose={() => setShowReportPreviewModal(false)}
                />
              </DialogContent>
            </Dialog>
          )}
        </main>
      </div>
    </div>
  );
};

export default ReportsPage;

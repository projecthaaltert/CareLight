import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Gebruikersbeheer from "@/components/admin/gebruikersbeheer";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";

export default function AdminPage() {
  const { user } = useAuth();

  // Alleen admin heeft toegang
  if (!user || user.role !== "admin") {
    return <Redirect to="/" />;
  }

  return (
    <div className="container py-10">
      <h1 className="text-4xl font-bold mb-8">Admin Dashboard</h1>
      
      <Tabs defaultValue="gebruikers" className="space-y-6">
        <TabsList>
          <TabsTrigger value="gebruikers">Gebruikersbeheer</TabsTrigger>
          <TabsTrigger value="systeem">Systeeminstellingen</TabsTrigger>
          <TabsTrigger value="logs">Logboeken</TabsTrigger>
        </TabsList>
        
        <TabsContent value="gebruikers">
          <Gebruikersbeheer />
        </TabsContent>
        
        <TabsContent value="systeem">
          <div className="bg-muted rounded-lg p-8 text-center">
            <h2 className="text-2xl font-semibold mb-4">Systeeminstellingen</h2>
            <p className="text-muted-foreground">
              Deze functionaliteit is momenteel in ontwikkeling.
            </p>
          </div>
        </TabsContent>
        
        <TabsContent value="logs">
          <div className="bg-muted rounded-lg p-8 text-center">
            <h2 className="text-2xl font-semibold mb-4">Systeemlogboeken</h2>
            <p className="text-muted-foreground">
              Deze functionaliteit is momenteel in ontwikkeling.
            </p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
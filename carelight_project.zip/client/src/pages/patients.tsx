import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Layout from "@/components/layout/layout";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Patient } from "@shared/schema";
import { format } from "date-fns";
import {
  Plus,
  Search,
  ChevronRight,
  Calendar,
  FileText,
  User,
  UserRoundX
} from "lucide-react";

export default function Patients() {
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  
  const { data: patients, isLoading } = useQuery<Patient[]>({
    queryKey: ["/api/patients"],
  });
  
  // Filter patients based on search query
  const filteredPatients = patients?.filter(patient => {
    if (!searchQuery.trim()) return true;
    
    const query = searchQuery.toLowerCase();
    return (
      patient.firstName.toLowerCase().includes(query) ||
      patient.lastName.toLowerCase().includes(query) ||
      patient.nationalId.toLowerCase().includes(query) ||
      (patient.email && patient.email.toLowerCase().includes(query))
    );
  });

  return (
    <Layout>
      <div className="p-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
          <div>
            <h1 className="text-2xl font-semibold text-gray-800">Patients</h1>
            <p className="text-sm text-gray-500">
              Manage your patient records
            </p>
          </div>
          
          <div className="mt-4 md:mt-0 flex flex-col sm:flex-row gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Search patients..."
                className="pl-9 w-full sm:w-64"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button onClick={() => navigate("/patients/new")}>
              <Plus className="h-4 w-4 mr-2" />
              Add Patient
            </Button>
          </div>
        </div>
        
        {isLoading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin h-8 w-8 border-4 border-primary-200 border-t-primary-500 rounded-full"></div>
            <p className="mt-2 text-gray-500">Loading patients...</p>
          </div>
        ) : filteredPatients?.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
            <UserRoundX className="h-12 w-12 text-gray-300 mx-auto mb-3" />
            <h3 className="text-lg font-medium text-gray-900">No patients found</h3>
            <p className="text-gray-500 mt-1">
              {searchQuery 
                ? "No patients match your search criteria." 
                : "You haven't added any patients yet."}
            </p>
            <Button className="mt-4" onClick={() => navigate("/patients/new")}>
              <Plus className="h-4 w-4 mr-2" />
              Add Patient
            </Button>
          </div>
        ) : (
          <div className="bg-white overflow-hidden shadow-sm rounded-lg border border-gray-200">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead className="w-[250px]">Name</TableHead>
                    <TableHead>ID</TableHead>
                    <TableHead>Date of Birth</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPatients?.map((patient) => (
                    <TableRow 
                      key={patient.id}
                      className="cursor-pointer hover:bg-gray-50"
                      onClick={() => navigate(`/patients/${patient.id}`)}
                    >
                      <TableCell className="font-medium">
                        <div className="flex items-center">
                          <User className="h-8 w-8 text-gray-400 bg-gray-100 p-1.5 rounded-full mr-2" />
                          <div>
                            <p>{patient.firstName} {patient.lastName}</p>
                            <p className="text-sm text-gray-500">
                              {patient.gender.charAt(0).toUpperCase() + patient.gender.slice(1)}
                            </p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{patient.nationalId}</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1 text-gray-400" />
                          {format(new Date(patient.dateOfBirth), "dd-MM-yyyy")}
                          <span className="ml-2 text-xs text-gray-500">
                            ({new Date().getFullYear() - new Date(patient.dateOfBirth).getFullYear()} yrs)
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="text-sm">{patient.phone}</div>
                          {patient.email && (
                            <div className="text-xs text-gray-500">{patient.email}</div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={(e) => {
                              e.stopPropagation();
                              navigate(`/patients/${patient.id}/prescriptions`);
                            }}
                          >
                            <FileText className="h-4 w-4 mr-1" />
                            <span className="hidden sm:inline">Prescriptions</span>
                          </Button>
                          <Button variant="ghost" size="sm">
                            <ChevronRight className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
